# Rule-baseline OOD: Patent-300 dataset
# Reference: ood_patent_300_full_pipeline.csv
"""
Rule-baseline batch runner — ZERO LLM calls.

Routes are parsed from the no_reflection log (iteration-1 Planner output),
so all three conditions share identical initial routes:

    no_reflection  : Planner → Critic (1 pass, no opt)
    rule_baseline  : same Planner routes → SOLVENT_DB substitution (this script)
    full_pipeline  : same Planner routes → Critic + Reflector loop

Usage:
    python experiments/run_rule_baseline_patent.py
    python experiments/run_rule_baseline_patent.py \\
        --log-source outputs/ood_patent_300_no_reflection_log.txt \\
        --input      data/patent_recent_300.csv \\
        --output     outputs/ood_patent_300_rule_baseline.csv \\
        --log-out    outputs/ood_patent_300_rule_baseline_log.txt
"""
import sys, os, csv, re, argparse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

from modules.models        import SynthesisRoute, ReactionStep
from modules.rule_baseline import run_rule_baseline
from rich.console import Console


# ── Log parser ────────────────────────────────────────────────────────────────

_MOL_HDR  = re.compile(r'^(\d+)/\d+ (.+)')
_ITER_HDR = re.compile(r'Iteration\s+(\d+)')
_STEP_ROW = re.compile(
    r'│\s+(\d+)\s+│\s*(.+?)\s*│\s+(.+?)\s+\?\s+│'
)


def parse_initial_routes(log_path: str, smiles_map: dict) -> list[dict]:
    results   = []
    cur_name  = cur_smiles = None
    cur_steps = []
    cur_iter  = None

    with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            m = _MOL_HDR.match(line)
            if m:
                if cur_name and cur_steps:
                    results.append({'name': cur_name, 'smiles': cur_smiles,
                                    'steps': cur_steps})
                cur_name   = m.group(2).strip()
                cur_smiles = smiles_map.get(cur_name, '')
                cur_steps  = []
                cur_iter   = None
                continue

            if '──' in line:
                m = _ITER_HDR.search(line)
                if m:
                    cur_iter = int(m.group(1))
                    continue

            if cur_iter == 1:
                m = _STEP_ROW.search(line)
                if m:
                    cur_steps.append({
                        'step':          int(m.group(1)),
                        'reaction_name': m.group(2).strip(),
                        'solvent':       m.group(3).strip(),
                        'conditions':    'see no_reflection log',
                    })

    if cur_name and cur_steps:
        results.append({'name': cur_name, 'smiles': cur_smiles,
                        'steps': cur_steps})

    return results


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--log-source', default='outputs/ood_patent_300_no_reflection_log.txt')
    p.add_argument('--input',      default='data/patent_recent_300.csv')
    p.add_argument('--output',     default='outputs/ood_patent_300_rule_baseline.csv')
    p.add_argument('--log-out',    default='outputs/ood_patent_300_rule_baseline_log.txt')
    args = p.parse_args()

    log_src  = os.path.join(ROOT, args.log_source)
    in_path  = os.path.join(ROOT, args.input)
    out_path = os.path.join(ROOT, args.output)
    log_path = os.path.join(ROOT, args.log_out)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    os.makedirs(os.path.dirname(log_path), exist_ok=True)

    log_file = open(log_path, 'w', encoding='utf-8')
    console  = Console(highlight=False)
    log_con  = Console(file=log_file, highlight=False, force_terminal=False)

    def cprint(msg):
        console.print(msg)
        log_con.print(msg)

    with open(in_path, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    smiles_map = {r['name']: r['smiles'] for r in rows}

    cprint(f"[cyan]Parsing initial routes from: {args.log_source}[/cyan]")
    route_data = parse_initial_routes(log_src, smiles_map)
    cprint(f"[cyan]Batch: {len(route_data)} molecules[/cyan]")

    results = []
    n = len(route_data)

    for i, rd in enumerate(route_data, 1):
        name   = rd['name']
        smiles = rd['smiles']
        steps  = rd['steps']

        cprint(f"[dim]{i}/{n} {name}[/dim]")

        if not smiles:
            cprint(f"[yellow]  Skip {name}: no SMILES in input CSV[/yellow]")
            continue
        if not steps:
            cprint(f"[yellow]  Skip {name}: no steps parsed from log[/yellow]")
            continue

        route = SynthesisRoute(
            molecule_name=name,
            smiles=smiles,
            steps=[
                ReactionStep(
                    step=s['step'],
                    reaction_name=s['reaction_name'],
                    reagents=[],
                    solvent=s['solvent'],
                    conditions=s['conditions'],
                )
                for s in steps
            ],
        )

        try:
            r = run_rule_baseline(route, smiles)

            init_score  = r.critique_history[0].overall_score
            final_score = r.final_green_score
            delta = final_score - init_score
            sign  = '+' if delta >= 0 else ''
            status = '[green]PASS[/green]' if r.passed else '[red]FAIL[/red]'
            cprint(f"  {status}  score {init_score} → {final_score} ({sign}{delta})  "
                   f"iter={r.total_iterations}  PMI={r.final_route.pmi}")
            for diff in r.reflection_diffs:
                for rep in diff.permitted_changes:
                    cprint(f"    [dim]Step {rep.step}: {rep.original_solvent} → "
                           f"{rep.replacement_solvent}[/dim]")

            results.append({
                'run_id':            r.config.run_id,
                'name':              name,
                'smiles':            smiles,
                'passed':            r.passed,
                'final_green_score': r.final_green_score,
                'pmi':               r.final_route.pmi,
                'total_iterations':  r.total_iterations,
            })

        except Exception as e:
            cprint(f"[red]  Error [{name}]: {e}[/red]")
            results.append({
                'run_id':            '',
                'name':              name,
                'smiles':            smiles,
                'passed':            False,
                'final_green_score': '',
                'pmi':               '',
                'total_iterations':  '',
            })

    FIELDS = ['run_id', 'name', 'smiles', 'passed', 'final_green_score',
              'pmi', 'total_iterations']
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(results)

    passed = sum(1 for r in results if r.get('passed'))
    total  = len(results)
    rate   = f"{100 * passed // total}%" if total else "0%"
    cprint(f"\n[bold]Done:[/bold] {total} molecules, pass rate {passed}/{total} ({rate})")
    cprint(f"[green]CSV  → {out_path}[/green]")
    cprint(f"[green]Log  → {log_path}[/green]")

    log_file.close()


if __name__ == '__main__':
    main()
