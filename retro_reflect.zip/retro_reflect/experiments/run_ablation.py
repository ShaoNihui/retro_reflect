"""
Ablation study: full pipeline vs no-reflection vs rule baseline.

Usage:
    python experiments/run_ablation.py --smiles "CC(=O)Oc1ccccc1C(=O)O"
    python experiments/run_ablation.py --config configs/ablation.yaml
"""
import sys, os, argparse, csv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))

from pipeline import run_pipeline
from rich.console import Console
from rich.table import Table

console = Console()


def run_ablation(smiles: str, name: str = "") -> dict:
    label = name or smiles[:30]
    console.rule(f"[bold]{label}[/bold]")

    results = {}
    for mode, kwargs in [
        ("rule_baseline", dict(use_reflection=False, rule_baseline=True)),
        ("no_reflection",  dict(use_reflection=False, rule_baseline=False)),
        ("full_pipeline",  dict(use_reflection=True,  rule_baseline=False)),
    ]:
        console.print(f"[dim]Running {mode}...[/dim]")
        try:
            r = run_pipeline(smiles=smiles, max_iter=3, **kwargs)
            results[mode] = {
                "green_score": r.final_green_score,
                "pmi":         r.final_route.pmi,
                "passed":      r.passed,
                "iterations":  r.total_iterations,
            }
        except Exception as e:
            console.print(f"[red]{mode} failed: {e}[/red]")
            results[mode] = {"error": str(e)}

    t = Table(title=label, show_header=True, header_style="bold")
    t.add_column("Mode"); t.add_column("Score"); t.add_column("PMI")
    t.add_column("Passed"); t.add_column("Iters")
    for mode, r in results.items():
        if "error" in r:
            t.add_row(mode, "[red]error[/red]", "-", "-", "-")
        else:
            sc = r["green_score"]
            t.add_row(
                mode,
                f"[green]{sc}/10[/green]" if sc >= 7 else f"[red]{sc}/10[/red]",
                str(r["pmi"]),
                "[green]Yes[/green]" if r["passed"] else "[red]No[/red]",
                str(r["iterations"]),
            )
    console.print(t)
    return {"molecule": label, "smiles": smiles, **results}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--smiles",  default=None)
    p.add_argument("--config",  default=None)
    p.add_argument("--output",  default="outputs/ablation_results.csv")
    args = p.parse_args()

    molecules = []
    if args.smiles:
        molecules = [{"smiles": args.smiles, "name": ""}]
    elif args.config:
        import yaml
        with open(os.path.join(ROOT, args.config)) as f:
            cfg = yaml.safe_load(f)
        molecules = cfg.get("molecules", [])
    else:
        molecules = [{"smiles": "CC(=O)Oc1ccccc1C(=O)O", "name": "Aspirin"}]

    all_results = [run_ablation(m["smiles"], m.get("name", "")) for m in molecules]

    out_path = os.path.join(ROOT, args.output)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    if all_results:
        flat = []
        for r in all_results:
            row = {"molecule": r["molecule"], "smiles": r["smiles"]}
            for mode in ["rule_baseline", "no_reflection", "full_pipeline"]:
                md = r.get(mode, {})
                row[f"{mode}_score"]  = md.get("green_score", "")
                row[f"{mode}_pmi"]    = md.get("pmi", "")
                row[f"{mode}_passed"] = md.get("passed", "")
                row[f"{mode}_iters"]  = md.get("iterations", "")
            flat.append(row)
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=flat[0].keys())
            writer.writeheader()
            writer.writerows(flat)
        console.print(f"[green]Saved → {out_path}[/green]")


if __name__ == "__main__":
    main()
