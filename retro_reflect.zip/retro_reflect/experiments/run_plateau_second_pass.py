"""
Second-pass experiment on plateau molecules (score=6, passed=False).
---------------------------------------------------------------------
The 715 molecules that stall at 6/10 contain steps with solvents scoring
5-6 (acetonitrile, methanol, acetone, THF…). The first pipeline never asks
for alternatives because the Critic only flags steps with score < 5.

This script relaxes that constraint:
  For every step with current score 5 or 6, ask an LLM:
    "Is there a greener alternative (score ≥ 7) that is chemically
     compatible with this reaction?"
  If yes → apply the suggestion → re-score with CriticModule.

Output labels:
  engineering_constraint : LLM found a greener alt AND route now passes
                           (the pipeline could in principle handle these)
  chemical_constraint    : LLM said the solvent is chemically required
                           OR no substitution led to passing score

Usage:
    python experiments/run_plateau_second_pass.py

Env:
    ANTHROPIC_API_KEY — use Claude Sonnet if set (recommended, lower cost)
    OPENAI_API_KEY    — fallback to GPT-4o when Anthropic key is absent

Estimated cost: ~$5-8 (715 molecules × ~2 consultant calls + 715 Critic calls)
"""
from __future__ import annotations
import sys, os, csv, re, json, copy, argparse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

from modules.models  import SynthesisRoute, ReactionStep
from modules.critic  import CriticModule, normalize_solvent
from data.solvent_db import SOLVENT_DB
from rich.console    import Console
from rich.panel      import Panel

# ── Constants ─────────────────────────────────────────────────────────────────
SECOND_PASS_SCORE_RANGE = (5, 6)   # ask about steps in this score band
TARGET_SCORE            = 7        # minimum step score we're aiming for

# ── LLM factory ───────────────────────────────────────────────────────────────

def _make_llm(temperature: float = 0.0):
    """
    Prefer Claude Sonnet (lower cost, chemistry-savvy).
    Falls back to GPT-4o when ANTHROPIC_API_KEY is absent.
    """
    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if anthropic_key:
        from langchain_anthropic import ChatAnthropic
        model = os.getenv("SECOND_PASS_MODEL", "claude-sonnet-4-5")
        return ChatAnthropic(model=model, temperature=temperature), model
    else:
        from langchain_openai import ChatOpenAI
        model = os.getenv("SECOND_PASS_MODEL", "gpt-4o")
        return ChatOpenAI(model=model, temperature=temperature), model


# ── Green-consultant prompt ────────────────────────────────────────────────────

_CONSULTANT_SYSTEM = """\
You are an expert organic chemist evaluating solvent substitution feasibility.
For each reaction step, assess how confident you are that the current solvent
can be replaced by a greener alternative without compromising the reaction.

Solvents are rated on a 1-10 green score:
  1-4  : hazardous (CMR, reproductive toxin, suspected carcinogen)
  5-6  : moderate concern (acetonitrile-5, methanol-6, acetone-6, THF variants-5/6)
  7-8  : preferred green (ethyl acetate-7, ethanol-7, 2-methyl-THF-7, water-8)
  9-10 : ideal (supercritical CO2-10)

Reply ONLY with valid JSON (no markdown fences, no explanation outside JSON):
{{"confidence": 85, "can_replace": true, "suggestion": "ethyl acetate", "reason": "one sentence chemical justification"}}
or
{{"confidence": 20, "can_replace": false, "suggestion": null, "reason": "one sentence chemical justification"}}
"""

_CONSULTANT_HUMAN = """\
In the reaction step '{reaction_name}', solvent '{solvent}' \
(ACS GCI score: {score}/10, hazard: {hazard}) is used under: {conditions}.

Rate your confidence (0-100) that this solvent CAN be replaced by a greener \
alternative (ACS GCI score ≥ 7) without affecting reaction outcome:

- 0-40  : Solvent is chemically required (specific mechanism dependency, \
protic/aprotic necessity, metal coordination, etc.)
- 41-85 : Uncertain — treat as chemical constraint
- 86-100: Solvent is replaceable (used by convention, not chemical necessity)

If confidence > 85, suggest a specific greener alternative.

Reply ONLY with valid JSON (no markdown, no explanation outside JSON):
{{"confidence": <0-100>, "can_replace": <true if confidence>85 else false>, \
"suggestion": "<solvent name or null>", "reason": "<one sentence>"}}
"""


def _make_consultant_chain(llm):
    return (
        ChatPromptTemplate.from_messages([
            ("system", _CONSULTANT_SYSTEM),
            ("human",  _CONSULTANT_HUMAN),
        ])
        | llm
        | JsonOutputParser()
    )


# ── DB helpers ─────────────────────────────────────────────────────────────────

def _db_score(solvent: str) -> tuple[int, str]:
    """Return (score, hazard) from SOLVENT_DB after normalization."""
    key = normalize_solvent(solvent).lower().strip()
    if key in SOLVENT_DB:
        return SOLVENT_DB[key]["score"], SOLVENT_DB[key]["hazard"]
    for k, v in SOLVENT_DB.items():
        if k in key or key in k:
            return v["score"], v["hazard"]
    return 3, "unknown solvent"


def _suggestion_score(suggestion: str | None) -> int:
    """Score a suggested solvent name; 0 if None or unrecognizable."""
    if not suggestion:
        return 0
    return _db_score(suggestion)[0]


# ── Log parser — reconstruct final route state ─────────────────────────────────

_MOL_HDR  = re.compile(r'^\d+/\d+ (.+)')
_ITER_HDR = re.compile(r'Iteration\s+(\d+)')
_STEP_ROW = re.compile(r'│\s+(\d+)\s+│\s*(.+?)\s*│\s+(.+?)\s+\?\s+│\s*(.*?)\s*│')
_REPL_ROW = re.compile(r'✓\s+Step\s+(\d+):\s*(.+?)\s+→\s+(.+)$')


def parse_final_routes(log_path: str, target_names: set[str]) -> dict[str, dict]:
    """
    Reconstruct the final solvent state for each target molecule:
      - Initial solvents from iteration-1 Planner table (rows with ?)
      - Overlaid with every ReflectionDiff substitution across all iterations

    Returns:
        {name: {step_num: {'reaction_name', 'solvent', 'conditions'}}}
    """
    result:       dict[str, dict] = {}
    cur_name:     str | None      = None
    init_steps:   dict            = {}   # step# -> {reaction_name, solvent, conditions}
    replacements: list            = []   # [(step#, new_solvent)]
    cur_iter:     int | None      = None
    in_refl:      bool            = False

    def _flush():
        if cur_name in target_names and init_steps:
            final = {n: d.copy() for n, d in init_steps.items()}
            for step_n, new_solv in replacements:
                if step_n in final:
                    final[step_n]["solvent"] = new_solv
            result[cur_name] = final

    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            # ── Molecule header ────────────────────────────────────────────
            m = _MOL_HDR.match(line)
            if m:
                _flush()
                cur_name     = m.group(1).strip()
                init_steps   = {}
                replacements = []
                cur_iter     = None
                in_refl      = False
                continue

            # ── Iteration header ───────────────────────────────────────────
            if "──" in line:
                m2 = _ITER_HDR.search(line)
                if m2:
                    cur_iter = int(m2.group(1))
                    in_refl  = False
                    continue

            # ── Iter-1 Planner table (solvents marked with ?) ──────────────
            if cur_iter == 1 and cur_name in target_names:
                m2 = _STEP_ROW.search(line)
                if m2:
                    step_n = int(m2.group(1))
                    init_steps[step_n] = {
                        "reaction_name": m2.group(2).strip(),
                        "solvent":       m2.group(3).strip(),
                        "conditions":    m2.group(4).strip() or "room temperature",
                    }

            # ── ReflectionDiff block ───────────────────────────────────────
            if "ReflectionDiff" in line:
                in_refl = True
                continue
            if in_refl:
                if "╰" in line:
                    in_refl = False
                    continue
                if "✓ Step" in line:
                    clean = re.sub(r"^\s*│\s*", "", line)
                    clean = re.sub(r"\s*│\s*$", "", clean).strip()
                    mm = _REPL_ROW.match(clean)
                    if mm:
                        step_n    = int(mm.group(1))
                        new_solv  = mm.group(3).strip()
                        if "(" not in new_solv and len(new_solv) <= 50:
                            replacements.append((step_n, new_solv))

    _flush()   # last molecule
    return result


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--csv-in",   default="outputs/final_2000_full_pipeline_v2.csv")
    p.add_argument("--log-in",   default="outputs/final_2000_full_pipeline_v2_log.txt")
    p.add_argument("--output",   default="outputs/final_2000_plateau_second_pass_v2.csv")
    p.add_argument("--log-out",  default="outputs/final_2000_plateau_second_pass_v2_log.txt")
    args = p.parse_args()

    csv_in  = os.path.join(ROOT, args.csv_in)
    log_in  = os.path.join(ROOT, args.log_in)
    out_csv = os.path.join(ROOT, args.output)
    out_log = os.path.join(ROOT, args.log_out)
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)

    log_file = open(out_log, "w", encoding="utf-8")
    console  = Console(highlight=False)
    log_con  = Console(file=log_file, highlight=False, force_terminal=False)

    def cprint(msg: str):
        console.print(msg)
        log_con.print(msg)

    # ── Step 1: Load plateau molecules ────────────────────────────────────────
    with open(csv_in, newline="", encoding="utf-8") as f:
        all_rows = list(csv.DictReader(f))

    plateau_rows = [
        r for r in all_rows
        if r["passed"].strip().lower() not in ("true", "1", "yes")
        and float(r["final_green_score"]) == 6.0
    ]
    plateau_names  = {r["name"] for r in plateau_rows}
    plateau_smiles = {r["name"]: r["smiles"] for r in plateau_rows}

    cprint(f"[cyan]Plateau molecules (score=6, passed=False): {len(plateau_rows)}[/cyan]")

    # ── Step 2: Build LLMs ────────────────────────────────────────────────────
    consultant_llm, cons_model = _make_llm(temperature=0.0)
    critic_llm,     crit_model = _make_llm(temperature=0.0)
    cprint(f"[cyan]Consultant LLM : {cons_model}[/cyan]")
    cprint(f"[cyan]Critic LLM     : {crit_model}[/cyan]")

    consultant_chain = _make_consultant_chain(consultant_llm)
    critic           = CriticModule(critic_llm)

    # ── Step 3: Parse final routes from log ───────────────────────────────────
    cprint(f"[cyan]Parsing final routes from log…[/cyan]")
    final_routes = parse_final_routes(log_in, plateau_names)
    cprint(f"[cyan]Routes parsed: {len(final_routes)} / {len(plateau_names)} targets[/cyan]")

    # ── Step 4: Second-pass loop ──────────────────────────────────────────────
    results        = []
    n_engineering  = 0   # passed after second-pass substitution
    n_chemical     = 0   # could not be improved
    n_skipped      = 0   # route not found in log (parse failure)
    n = len(plateau_rows)

    FIELDS = ["run_id", "name", "smiles", "passed",
              "final_green_score", "pmi", "total_iterations"]

    for i, row in enumerate(plateau_rows, 1):
        name   = row["name"]
        smiles = plateau_smiles[name]
        cprint(f"\n[dim]{i}/{n} {name}[/dim]")

        if name not in final_routes:
            cprint(f"  [yellow]Skip: route not found in log[/yellow]")
            n_skipped += 1
            results.append({
                "run_id":            row.get("run_id", ""),
                "name":              name,
                "smiles":            smiles,
                "passed":            False,
                "final_green_score": 6,
                "pmi":               row.get("pmi", ""),
                "total_iterations":  row.get("total_iterations", ""),
            })
            continue

        step_data = final_routes[name]   # {step_n: {reaction_name, solvent, conditions}}

        # ── Score each step from SOLVENT_DB ───────────────────────────────
        step_scores = {}
        for step_n, sd in step_data.items():
            score, hazard = _db_score(sd["solvent"])
            step_scores[step_n] = (score, hazard)

        # ── Identify steps to consult about (score in 5-6 band) ───────────
        target_steps = [
            step_n for step_n, (sc, _) in step_scores.items()
            if SECOND_PASS_SCORE_RANGE[0] <= sc <= SECOND_PASS_SCORE_RANGE[1]
        ]
        cprint(f"  Steps with score 5-6: {sorted(target_steps)}")

        # ── Ask consultant for each target step ───────────────────────────
        substitutions = {}   # step_n -> suggested_solvent (only if can_replace and score≥7)

        for step_n in sorted(target_steps):
            sd    = step_data[step_n]
            score, hazard = step_scores[step_n]
            try:
                resp = consultant_chain.invoke({
                    "reaction_name": sd["reaction_name"],
                    "solvent":       sd["solvent"],
                    "score":         score,
                    "hazard":        hazard,
                    "conditions":    sd["conditions"],
                })
                confidence  = int(resp.get("confidence", 0))
                can_replace = confidence > 85
                suggestion  = resp.get("suggestion") or ""
                reason      = resp.get("reason", "")
            except Exception as e:
                cprint(f"  [red]Consultant error step {step_n}: {e}[/red]")
                confidence  = 0
                can_replace = False
                suggestion  = ""
                reason      = str(e)

            suggestion = suggestion.strip().lower() if suggestion else ""
            sugg_score = _suggestion_score(suggestion) if suggestion else 0

            if can_replace and suggestion and sugg_score >= TARGET_SCORE:
                substitutions[step_n] = suggestion
                cprint(f"  Step {step_n}: [yellow]{sd['solvent']}({score})[/yellow] → "
                       f"[green]{suggestion}({sugg_score})[/green]  "
                       f"✓ confidence={confidence} — {reason}")
            else:
                flag = (f"confidence={confidence}≤70" if not can_replace else
                        f"suggestion '{suggestion}' scores {sugg_score}/10 < 7"
                        if suggestion else "no suggestion")
                cprint(f"  Step {step_n}: [yellow]{sd['solvent']}({score})[/yellow]  "
                       f"[dim]chemical constraint — {reason[:80]} ({flag})[/dim]")

        # ── Apply substitutions and re-score with CriticModule ─────────────
        revised_data = copy.deepcopy(step_data)
        for step_n, new_solv in substitutions.items():
            revised_data[step_n]["solvent"] = new_solv

        # Build SynthesisRoute for Critic
        route = SynthesisRoute(
            molecule_name=name,
            smiles=smiles,
            steps=[
                ReactionStep(
                    step=step_n,
                    reaction_name=revised_data[step_n]["reaction_name"],
                    reagents=[],
                    solvent=revised_data[step_n]["solvent"],
                    conditions=revised_data[step_n]["conditions"],
                )
                for step_n in sorted(revised_data)
            ],
        )

        if substitutions:
            try:
                feedback = critic.evaluate(route)
                final_score = feedback.overall_score
                passed      = feedback.passed
                pmi         = route.pmi
            except Exception as e:
                cprint(f"  [red]Critic error: {e}[/red]")
                final_score = 6
                passed      = False
                pmi         = float(row.get("pmi", 0) or 0)
        else:
            # No substitution made — still fails
            final_score = 6
            passed      = False
            pmi         = float(row.get("pmi", 0) or 0)

        if passed:
            n_engineering += 1
            cprint(f"  [green bold]PASS[/green bold]  score {final_score}/10 → engineering constraint")
        else:
            n_chemical += 1
            cprint(f"  [red]FAIL[/red]  score {final_score}/10 → chemical constraint")

        results.append({
            "run_id":            row.get("run_id", ""),
            "name":              name,
            "smiles":            smiles,
            "passed":            passed,
            "final_green_score": final_score,
            "pmi":               round(pmi, 1),
            "total_iterations":  int(row.get("total_iterations", 3)) + 1,
        })

    # ── Save CSV ──────────────────────────────────────────────────────────────
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    # ── Summary ───────────────────────────────────────────────────────────────
    n_total = len(plateau_rows)
    cprint("")
    cprint(Panel(
        f"[bold]Plateau Second-Pass Results[/bold]\n\n"
        f"  Input molecules       : {n_total}\n"
        f"  Routes parsed         : {len(final_routes)}  (skipped: {n_skipped})\n"
        f"\n"
        f"  [green]Engineering constraint (passed)[/green] : {n_engineering} "
        f"({n_engineering/n_total*100:.1f}%)\n"
        f"  [red]Chemical constraint   (failed)[/red] : {n_chemical} "
        f"({n_chemical/n_total*100:.1f}%)\n"
        f"\n"
        f"  Of original 2000 molecules:\n"
        f"    Before second pass  : 1005/2000 = 50.2% passed\n"
        f"    After  second pass  : {1005 + n_engineering}/2000 = "
        f"{(1005 + n_engineering)/2000*100:.1f}% passed (+{n_engineering/2000*100:.1f}pp)\n"
        f"\n"
        f"  CSV → {out_csv}\n"
        f"  Log → {out_log}",
        title="Summary", border_style="cyan",
    ))

    log_file.close()


if __name__ == "__main__":
    main()
