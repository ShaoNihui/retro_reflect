"""
Single molecule run.

Usage:
    python experiments/run_single.py --smiles "CC(=O)Oc1ccccc1C(=O)O"
    python experiments/run_single.py --smiles "..." --no-reflection
    python experiments/run_single.py --smiles "..." --rule-baseline
"""
import sys, os, argparse, json

# Works without pip install -e — just needs to be run from project root
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))

from pipeline import run_pipeline
from rich.console import Console
console = Console()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--smiles",        required=True)
    p.add_argument("--max-iter",      type=int, default=3)
    p.add_argument("--no-reflection", action="store_true")
    p.add_argument("--rule-baseline", action="store_true")
    p.add_argument("--output",        default=None)
    args = p.parse_args()

    result = run_pipeline(
        smiles=args.smiles,
        max_iter=args.max_iter,
        use_reflection=not args.no_reflection,
        rule_baseline=args.rule_baseline,
    )

    console.print(
        f"\n[bold]Final score:[/bold] {result.final_green_score}/10  "
        f"[bold]Passed:[/bold] {'[green]Yes[/green]' if result.passed else '[red]No[/red]'}  "
        f"[bold]Iterations:[/bold] {result.total_iterations}"
    )

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w") as f:
            json.dump(result.model_dump(), f, indent=2, default=str)
        console.print(f"[dim]Saved → {args.output}[/dim]")


if __name__ == "__main__":
    main()
