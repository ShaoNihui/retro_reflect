"""
Batch evaluation over a CSV of SMILES strings.

Usage:
    python experiments/run_batch.py --input data/uspto_50k_sample.csv
    python experiments/run_batch.py --config configs/batch.yaml
"""
import sys, os, csv, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))

from pipeline import run_pipeline
from rich.console import Console
console = Console()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input",  default="data/uspto_50k_sample.csv")
    p.add_argument("--output", default="outputs/batch_results.csv")
    p.add_argument("--config", default=None)
    p.add_argument("--limit",  type=int, default=None)
    p.add_argument("--no-reflection", action="store_true")
    p.add_argument("--rule-baseline", action="store_true")
    args = p.parse_args()
    args.use_reflection = not args.no_reflection
    args.rule_baseline = args.rule_baseline if hasattr(args, "rule_baseline") else False

    if args.config:
        import yaml
        with open(os.path.join(ROOT, args.config)) as f:
            cfg = yaml.safe_load(f)
        exp = cfg.get("experiment", {})
        args.input  = exp.get("input_csv",  args.input)
        args.output = exp.get("output_csv", args.output)
        args.limit  = exp.get("max_molecules", args.limit)

    in_path  = os.path.join(ROOT, args.input)
    out_path = os.path.join(ROOT, args.output)

    with open(in_path, newline="") as f:
        rows = list(csv.DictReader(f))
    if args.limit:
        rows = rows[:args.limit]

    console.print(f"[cyan]Batch: {len(rows)} molecules[/cyan]")

    results = []
    for i, row in enumerate(rows, 1):
        smiles = row.get("smiles", "").strip()
        name   = row.get("name", smiles[:20])
        if not smiles:
            continue
        console.print(f"[dim]{i}/{len(rows)} {name}[/dim]")
        try:
            r = run_pipeline(smiles=smiles, max_iter=3, use_reflection=args.use_reflection, rule_baseline=getattr(args, "rule_baseline", False))
            results.append({
                "run_id":            r.config.run_id if r.config else "",
                "name":              name,
                "smiles":            smiles,
                "passed":            r.passed,
                "final_green_score": r.final_green_score,
                "pmi":               r.final_route.pmi,
                "total_iterations":  r.total_iterations,
            })
        except Exception as e:
            console.print(f"[red]Error [{name}]: {e}[/red]")
            results.append({"name": name, "smiles": smiles, "error": str(e)})

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    if results:
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)

    passed = sum(1 for r in results if r.get("passed"))
    total  = len(results)
    console.print(
        f"\n[bold]Done:[/bold] {total} molecules, "
        f"pass rate {passed}/{total} ({100*passed//total if total else 0}%)\n"
        f"[green]Saved → {out_path}[/green]"
    )


if __name__ == "__main__":
    main()
