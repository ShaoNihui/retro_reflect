# No-Reflection baseline re-run with fixed solvent DB
# Re-run no_reflection with updated solvent DB to ensure fair comparison with ablation
# Reference: final_2000_no_reflection.csv (old DB, Apr 5, pass rate 1.6%)
"""
Fixed configuration:
  use_reflection = False  (Planner + Critic single pass, no reflection loop)
  PLANNER_MODEL  = gpt-4o (temperature=0.3)
  CRITIC_MODEL   = gpt-4o (temperature=0.0)  -- identical to main experiment

Output:
  outputs/final_2000_no_reflection_v2.csv
"""
from __future__ import annotations
import sys, os, csv, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "retro_reflect"))

# ── CLI ────────────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("--test", action="store_true", help="Run on first 30 molecules only")
args = parser.parse_args()

FIELDS  = ["run_id", "name", "smiles", "passed", "final_green_score", "pmi", "total_iterations"]
IN_CSV  = os.path.join(ROOT, "data", "uspto_stratified_2000.csv")
OUT_CSV = (os.path.join(ROOT, "outputs", "test_30_no_reflection_v2.csv")
           if args.test else
           os.path.join(ROOT, "outputs", "final_2000_no_reflection_v2.csv"))
OUT_LOG = OUT_CSV.replace(".csv", "_log.txt")

# ── Tee stdout → log file (must happen before pipeline import) ─────────────────
os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
_log_fh = open(OUT_LOG, "w", encoding="utf-8")

class _Tee:
    def __init__(self, *streams): self.streams = streams
    def write(self, data):
        for s in self.streams: s.write(data)
    def flush(self):
        for s in self.streams: s.flush()
    def isatty(self): return False

sys.stdout = _Tee(sys.__stdout__, _log_fh)
sys.stderr = _Tee(sys.__stderr__, _log_fh)

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))

from pipeline import run_pipeline
from rich.console import Console

console = Console()


def main():
    with open(IN_CSV, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    if args.test:
        rows = rows[:30]

    console.print(f"[cyan]No-Reflection v2 (fixed DB): {len(rows)} molecules → {OUT_CSV}[/cyan]")

    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)

    with open(OUT_CSV, "w", newline="", encoding="utf-8") as out_f:
        writer = csv.DictWriter(out_f, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()

        passed_total = 0
        for i, row in enumerate(rows, 1):
            smiles = row.get("smiles", "").strip()
            name   = row.get("name", smiles[:20])
            if not smiles:
                continue
            console.print(f"[dim]{i}/{len(rows)} {name}[/dim]")
            try:
                r = run_pipeline(smiles=smiles, max_iter=3, use_reflection=False)
                record = {
                    "run_id":            r.config.run_id if r.config else "",
                    "name":              name,
                    "smiles":            smiles,
                    "passed":            r.passed,
                    "final_green_score": r.final_green_score,
                    "pmi":               round(r.final_route.pmi, 1),
                    "total_iterations":  r.total_iterations,
                }
                passed_total += int(bool(r.passed))
            except Exception as e:
                console.print(f"[red]Error [{name}]: {e}[/red]")
                record = {
                    "run_id": "", "name": name, "smiles": smiles,
                    "passed": False, "final_green_score": 0,
                    "pmi": 0.0, "total_iterations": 0,
                }
            writer.writerow(record)
            out_f.flush()

    console.print(
        f"\n[bold]Done:[/bold] {len(rows)} molecules, "
        f"pass rate {passed_total}/{len(rows)} "
        f"({100*passed_total/len(rows):.1f}%)\n"
        f"[green]Saved → {OUT_CSV}[/green]"
    )
    _log_fh.flush()
    _log_fh.close()


if __name__ == "__main__":
    main()
