"""
pytest root conftest — adds all necessary paths for Python 3.9 compatibility.
No pip install -e needed. Just run: pytest tests/ -v
"""
import sys, os

root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, root)
sys.path.insert(0, os.path.join(root, "retro_reflect"))
