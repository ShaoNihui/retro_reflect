# Experiment Data Summary — retro_reflect_v2 (N=2000)

> Sources: `final_2000_full_pipeline.csv`, `final_2000_no_reflection.csv`,
> `final_2000_full_pipeline_log.txt`, `final_2000_no_reflection_log.txt`
> Date extracted: 2026-04-26

---

## 1. Basic Statistics

| Metric | Full Pipeline | No Reflection |
|---|---|---|
| N (molecules) | 2000 | 2000 |
| Pass Count | 1005 | 33 |
| **Pass Rate** | **50.2%** | **1.7%** |
| Avg Green Score (/10) | 6.3 | 4.0 |
| Avg PMI | 11.7 | 15.5 |
| Avg Iterations | 2.4 | 1.0 |

---

## 2. McNemar Contingency Table (Paired, N=1999)

> Note: 1999 matched run_ids (1 molecule missing from one condition).

| | No-Reflection PASS | No-Reflection FAIL |
|---|---|---|
| **Full Pipeline PASS** | a = 28 | b = 976 |
| **Full Pipeline FAIL** | c = 5 | d = 990 |

- b − c = 971 (net gain from reflection)
- McNemar statistic: χ² = (b−c)² / (b+c) = 971² / 981 ≈ **962.0** (p ≪ 0.001)

---

## 3. Iteration Distribution (Full Pipeline)

| Iterations | Count | % of Total |
|---|---|---|
| 1 round | 39 | 2.0% |
| 2 rounds | 1137 | 56.9% |
| 3 rounds | 824 | 41.2% |
| **≤ 2 rounds (convergence rate)** | **1176** | **58.8%** |

---

## 4. Failure Mode Classification (Full Pipeline, 995 failures)

| Category | Count | % of Failures |
|---|---|---|
| Score = 6/10 (plateau) | 715 | 71.9% |
| Score = 5/10 (near-miss) | 131 | 13.2% |
| Score ≤ 4/10 | 149 | 15.0% |
| **Total failures** | **995** | **100.0%** |

> Cross-cutting: **PMI = 0** in 82 failed molecules (8.2% of failures; overlaps with score categories above).

Score breakdown among ≤ 4/10 failures: score 4: 75, score 3: 47, score 2: 26, score 1: 1.

---

## 5. Per-Round Cumulative Pass Rate (Full Pipeline)

| After Round | New Passes | Cumulative Passes | Cumulative Pass Rate |
|---|---|---|---|
| Round 1 | 35 | 35 | 1.8% |
| Round 2 | 849 | 884 | 44.2% |
| Round 3 | 121 | 1005 | 50.2% |

> Round 2 accounts for **84.5%** of all eventual passes (849/1005).

---

## 6. Initial Solvent Distribution — Top 15 (No-Reflection Planner, N=7249 step-slots)

| Rank | Solvent | Count | % |
|---|---|---|---|
| 1 | DCM (dichloromethane) | 1631 | 22.5% |
| 2 | Toluene | 1031 | 14.2% |
| 3 | Ethanol | 964 | 13.3% |
| 4 | Methanol | 803 | 11.1% |
| 5 | Dioxane | 683 | 9.4% |
| 6 | DMF | 548 | 7.6% |
| 7 | THF | 443 | 6.1% |
| 8 | Acetonitrile | 369 | 5.1% |
| 9 | Water | 168 | 2.3% |
| 10 | Acetone | 152 | 2.1% |
| 11 | Chloroform | 120 | 1.7% |
| 12 | Acetic acid | 89 | 1.2% |
| 13 | Sulfuric acid | 53 | 0.7% |
| 14 | None | 36 | 0.5% |
| 15 | Diethyl ether | 36 | 0.5% |

> Synonym merges applied: dimethylformamide → DMF, dichloromethane → DCM, tetrahydrofuran → THF.

---

## 7. Solvent Replacement Statistics (Full Pipeline ReflectionDiff, N=4549 clean replacements)

### 7a. Top-15 Replaced (FROM) Solvents

| Rank | Solvent | Count | % |
|---|---|---|---|
| 1 | DCM | 1684 | 37.0% |
| 2 | Toluene | 1035 | 22.8% |
| 3 | Dioxane | 689 | 15.1% |
| 4 | DMF | 515 | 11.3% |
| 5 | DMSO | 257 | 5.6% |
| 6 | Chloroform | 100 | 2.2% |
| 7 | DME | 74 | 1.6% |
| 8 | Sulfuric acid | 54 | 1.2% |
| 9 | None | 35 | 0.8% |
| 10 | Carbon tetrachloride | 31 | 0.7% |
| 11 | Pyridine | 31 | 0.7% |
| 12 | THF | 15 | 0.3% |
| 13 | Benzene | 11 | 0.2% |
| 14 | Xylene | 10 | 0.2% |
| 15 | Ethylene glycol | 6 | 0.1% |

### 7b. Top-15 Replacement (TO) Solvents

| Rank | Solvent | Count | % |
|---|---|---|---|
| 1 | **Ethyl acetate** | **3358** | **73.8%** |
| 2 | **2-Methyl tetrahydrofuran** | **587** | **12.9%** |
| 3 | **Dimethyl carbonate** | **372** | **8.2%** |
| 4 | Water | 75 | 1.6% |
| 5 | Acetone | 24 | 0.5% |
| 6 | Methyl tert-butyl ether | 24 | 0.5% |
| 7 | Ethanol | 24 | 0.5% |
| 8 | Acetic acid | 21 | 0.5% |
| 9 | DCM | 15 | 0.3% |
| 10 | Cyclopentyl methyl ether | 13 | 0.3% |
| 11 | Dimethyl sulfoxide | 11 | 0.2% |
| 12 | Acetonitrile | 6 | 0.1% |
| 13 | 1,2-Dichloroethane | 5 | 0.1% |
| 14 | Methanol | 5 | 0.1% |
| 15 | Toluene | 4 | 0.1% |

### 7c. Key Green Solvent Proportions (as % of all replacements)

| Solvent | Count | % of Total Replacements |
|---|---|---|
| Ethyl acetate | 3358 | 73.8% |
| 2-Methyl tetrahydrofuran | 587 | 12.9% |
| Dimethyl carbonate | 372 | 8.2% |
| **Combined green solvents** | **4317** | **94.9%** |

> Synonym merge: "2-methyltetrahydrofuran" + "2-methyl tetrahydrofuran" combined = 587.
> "Replace with X" noise entries (46 total) excluded from clean count.

---

## 8. ValidityCheck Statistics (Full Pipeline)

| Metric | Value |
|---|---|
| Total "Blocking issues:" occurrences | 300 |
| Total "Re-planning (retry)" occurrences | 296 |
| Blocking events per molecule (avg) | 0.2 |
| Molecules with at least one blocking event | ~296 (est.) |

---

## 9. Cost Statistics

| Metric | Value |
|---|---|
| Total estimated cost | ~USD 50 |
| Molecules processed | 2000 |
| **Average cost per molecule** | **~USD 0.025 (2.5 cents)** |
| Average iterations (full pipeline) | 2.4 |
| Cost per iteration (est.) | ~USD 0.010 |

---

## Fig. 3b — Class8 Solvent Transition Matrix (N=32 molecules, 74 replacement events)

> Parsed from `full_pipeline_log.txt` ReflectionDiff blocks.
> Synonym merges applied (same as §6/§7). Noise entries ("replace with X") merged into canonical target.

### Transition Table (FROM → TO, counts)

| FROM Solvent | EtOAc | 2-MeTHF | DMC | Acetone | MTBE | Water | **Row Total** |
|---|---|---|---|---|---|---|---|
| DCM | 34 | — | — | — | — | — | **34** |
| Toluene | 10 | 2 | — | — | 1 | — | **13** |
| Dioxane | 8 | — | — | — | — | — | **8** |
| DMSO | 4 | — | — | — | — | — | **4** |
| Chloroform | 2 | — | 1 | — | — | — | **3** |
| DME | — | 3 | — | — | — | — | **3** |
| DMF | 1 | — | 1 | 1 | — | — | **3** |
| Xylene | — | — | 2 | — | — | — | **2** |
| Carbon tetrachloride | 1 | — | — | — | — | — | **1** |
| Ethylene glycol | — | — | — | — | — | 1 | **1** |
| Sulfuric acid | — | — | — | — | — | 1 | **1** |
| THF | — | 1 | — | — | — | — | **1** |
| **Col Total** | **60** | **6** | **4** | **1** | **1** | **2** | **74** |
| **%** | **81.1%** | **8.1%** | **5.4%** | **1.4%** | **1.4%** | **2.7%** | |

> Abbreviations: EtOAc = ethyl acetate, 2-MeTHF = 2-methyl tetrahydrofuran, DMC = dimethyl carbonate,
> MTBE = methyl tert-butyl ether, DME = dimethoxyethane.

### Key Observations

- **DCM** is the dominant replaced solvent (34/74 = **45.9%** of all class8 replacements), exclusively replaced by ethyl acetate.
- **Ethyl acetate** is the dominant replacement target (60/74 = **81.1%**).
- **Ether-class** solvents (DME, THF) route exclusively to 2-MeTHF (4/74 = 5.4%).
- Avg replacements per class8 molecule: 74 / 32 = **2.3 events/mol**.

---

## Fig. 5d — Unreplaced Solvents in Score=6 Plateau Molecules (N=715)

> Plateau = `final_green_score == 6.0` AND `passed == False`.
> "Unreplaced step" = a step whose initial solvent (iter 1 planner) was never modified across all ReflectionDiff blocks for that molecule.
> N=715 plateau molecules, 1125 unreplaced step-slots (avg **1.6 unreplaced steps/mol**).

### Unreplaced Solvent Distribution

| Rank | Solvent | Count | % of Unreplaced Slots |
|---|---|---|---|
| 1 | Methanol | 434 | 38.6% |
| 2 | Acetonitrile | 282 | 25.1% |
| 3 | Ethanol | 169 | 15.0% |
| 4 | THF | 148 | 13.2% |
| 5 | Acetone | 79 | 7.0% |
| 6 | Acetic acid | 5 | 0.4% |
| 7 | Water | 4 | 0.4% |
| 8 | Ethyl acetate | 2 | 0.2% |
| 9 | t-Butanol | 1 | 0.1% |
| 10 | DMF | 1 | 0.1% |

### Key Observations

- The top-4 solvents (methanol, acetonitrile, ethanol, THF) account for **92.0%** of all unreplaced slots.
- These are all moderate-scoring solvents (green score ≈ 5–6 each): individually they pass the per-step critic threshold, so no replacement is triggered — but they collectively cap the route score at 6/10.
- **Methanol** alone accounts for 38.6% of plateau stalls, suggesting it is the single most common "acceptable-but-not-green-enough" bottleneck.
- None of the classic hazardous solvents (DCM, DMF, dioxane, toluene) appear in unreplaced slots, confirming the critic reliably flags and replaces them.
