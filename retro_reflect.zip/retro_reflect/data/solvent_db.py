# ACS Green Chemistry Institute - Solvent Selection Guide
# score: 0 (worst) to 10 (best)

SOLVENT_DB = {
    # Score 0 - Banned / Highly Hazardous
    "benzene":          {"score": 0,  "hazard": "known carcinogen",         "alt": "toluene or ethanol"},
    "carbon tetrachloride": {"score": 0, "hazard": "carcinogen, ozone depleting", "alt": "ethyl acetate"},

    # Score 1-2 - Highly Problematic
    "chloroform":       {"score": 1,  "hazard": "suspected carcinogen",     "alt": "ethyl acetate"},
    "dichloromethane":  {"score": 2,  "hazard": "suspected carcinogen",     "alt": "ethyl acetate or 2-MeTHF"},
    "dcm":              {"score": 2,  "hazard": "suspected carcinogen",     "alt": "ethyl acetate"},

    # Score 3 - Hazardous
    "dmf":              {"score": 3,  "hazard": "reproductive toxin",       "alt": "ethanol or 2-MeTHF"},
    "toluene":          {"score": 3,  "hazard": "neurotoxin",               "alt": "ethanol"},
    "dioxane":          {"score": 3,  "hazard": "carcinogen",               "alt": "THF or ethyl acetate"},
    "dmso":             {"score": 3,  "hazard": "enhances skin absorption", "alt": "ethanol"},

    # Score 4 - Problematic
    "thf":              {"score": 4,  "hazard": "flammable, peroxide forming","alt": "2-MeTHF or ethyl acetate"},
    "dme":              {"score": 4,  "hazard": "flammable, peroxide forming","alt": "2-MeTHF"},

    # Score 5 - Usable but Concerns
    "acetonitrile":     {"score": 5,  "hazard": "moderate toxicity",        "alt": "acetone"},
    "nitromethane":     {"score": 5,  "hazard": "flammable",                "alt": "acetone"},

    # Score 6 - Acceptable
    "acetone":          {"score": 6,  "hazard": "flammable, low toxicity",  "alt": None},
    "methanol":         {"score": 6,  "hazard": "toxic if ingested",        "alt": "ethanol"},
    "cyclohexane":      {"score": 6,  "hazard": "flammable",                "alt": "heptane"},

    # Score 7 - Recommended
    "ethyl acetate":    {"score": 7,  "hazard": "low toxicity, biodegradable", "alt": None},
    "isopropanol":      {"score": 7,  "hazard": "low toxicity",             "alt": None},
    "2-methylthf":      {"score": 7,  "hazard": "bio-based, low toxicity",  "alt": None},
    "2-methyl tetrahydrofuran": {"score": 7, "hazard": "bio-based, low toxicity", "alt": None},
    "2-mthf":          {"score": 7,  "hazard": "bio-based, low toxicity",  "alt": None},
    "2-meTHF":          {"score": 7,  "hazard": "bio-based, low toxicity",  "alt": None},
    "heptane":          {"score": 7,  "hazard": "low toxicity",             "alt": None},

    # Score 8 - Preferred
    "ethanol":          {"score": 8,  "hazard": "bio-based, renewable",     "alt": None},
    "propanol":         {"score": 8,  "hazard": "low toxicity",             "alt": None},

    # Score 9
    "acetic acid":      {"score": 9,  "hazard": "corrosive but green",      "alt": None},

    # High-boiling solvents for PAH synthesis
    "xylene":       {"score": 3,  "hazard": "neurotoxin, flammable",       "alt": "toluene"},
    "quinoline":    {"score": 2,  "hazard": "toxic, suspected carcinogen",  "alt": "toluene"},
    "mesitylene":   {"score": 3,  "hazard": "flammable, irritant",         "alt": "toluene"},
    "naphthalene":  {"score": 2,  "hazard": "possible carcinogen",         "alt": "toluene"},

    # Solvent-free conditions
    "neat":             {"score": 8,  "hazard": "solvent-free, green practice", "alt": None},
    "solvent-free":     {"score": 8,  "hazard": "solvent-free, green practice", "alt": None},
    "no solvent":       {"score": 8,  "hazard": "solvent-free, green practice", "alt": None},

    # Score 10 - Ideal
    "water":            {"score": 10, "hazard": "none",                     "alt": None},

    # ── Extended entries ──────────────────────────────────────────────────────

    # Score 2 - Hazardous chlorinated
    "1,2-dichloroethane":       {"score": 2, "hazard": "carcinogen, toxic",              "alt": "ethyl acetate"},
    "chlorobenzene":            {"score": 2, "hazard": "toxic, flammable",               "alt": "toluene"},

    # Score 3
    "nitrobenzene":             {"score": 3, "hazard": "toxic, environmental hazard",    "alt": "toluene"},
    "pyridine":                 {"score": 3, "hazard": "flammable, irritant, toxic",     "alt": "triethylamine"},
    "pentane":                  {"score": 3, "hazard": "extremely flammable, neurotoxic","alt": "heptane"},
    "n-pentane":                {"score": 3, "hazard": "extremely flammable, neurotoxic","alt": "heptane"},

    # Score 4
    "hexane":                   {"score": 4, "hazard": "neurotoxic, flammable, VOC",     "alt": "heptane"},
    "n-hexane":                 {"score": 4, "hazard": "neurotoxic, flammable, VOC",     "alt": "heptane"},
    "diglyme":                  {"score": 4, "hazard": "flammable, peroxide forming",    "alt": "2-MeTHF"},
    "1,2-dimethoxyethane":      {"score": 4, "hazard": "flammable, peroxide forming",   "alt": "2-MeTHF"},

    # Score 5
    "mtbe":                     {"score": 5, "hazard": "flammable, groundwater risk",    "alt": "2-MeTHF"},
    "methyl tert-butyl ether":  {"score": 5, "hazard": "flammable, groundwater risk",   "alt": "2-MeTHF"},

    # Score 6
    "tert-butanol":             {"score": 6, "hazard": "flammable, low toxicity",        "alt": "ethanol"},
    "n-butanol":                {"score": 6, "hazard": "flammable, irritant",            "alt": "ethanol"},
    "butanol":                  {"score": 6, "hazard": "flammable, irritant",            "alt": "ethanol"},
    "butyl acetate":            {"score": 6, "hazard": "flammable, low toxicity",        "alt": "ethyl acetate"},
    "anisole":                  {"score": 6, "hazard": "flammable, low toxicity",        "alt": None},
    "cyclopentanone":           {"score": 6, "hazard": "flammable, low toxicity",        "alt": "acetone"},

    # Score 7 - Recommended
    "dimethyl carbonate":       {"score": 7, "hazard": "low toxicity, biodegradable",    "alt": None},
    "isopropyl acetate":        {"score": 7, "hazard": "low toxicity, biodegradable",    "alt": None},
    "2-butanol":                {"score": 7, "hazard": "low toxicity",                   "alt": None},
    "sec-butanol":              {"score": 7, "hazard": "low toxicity",                   "alt": None},
    "isobutanol":               {"score": 7, "hazard": "low toxicity, bio-based",        "alt": None},
    "cyclopentyl methyl ether": {"score": 7, "hazard": "low toxicity, bio-based",        "alt": None},
    "cpme":                     {"score": 7, "hazard": "low toxicity, bio-based",        "alt": None},

    # Score 8 - Preferred
    "ethylene glycol":          {"score": 7, "hazard": "low oral toxicity, renewable",   "alt": None},
    "propylene glycol":         {"score": 8, "hazard": "non-toxic, bio-based",           "alt": None},
    "glycerol":                 {"score": 9, "hazard": "non-toxic, renewable",           "alt": None},
}
