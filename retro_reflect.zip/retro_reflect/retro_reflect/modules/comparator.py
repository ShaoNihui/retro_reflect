"""
Comparator Module
-----------------
Fix 6: Uses step.green_score (always int after Critic runs) directly.
       Single scoring formula: int(mean of step scores), same as CriticModule.
"""
from __future__ import annotations
from modules.models import SynthesisRoute, CriticFeedback, PipelineResult
from data.solvent_db import SOLVENT_DB


def _step_score(solvent: str) -> int:
    """Fix 6: identical lookup used in Critic, Comparator, and rule_baseline."""
    key = solvent.lower().strip()
    if key in SOLVENT_DB:
        return SOLVENT_DB[key]["score"]
    for k, v in SOLVENT_DB.items():
        if k in key or key in k:
            return v["score"]
    return 6


class ComparatorModule:

    def compare(self, result: PipelineResult) -> dict:
        initial = result.iteration_history[0]
        final   = result.final_route
        c_init  = result.critique_history[0]  if result.critique_history else None
        c_final = result.critique_history[-1] if result.critique_history else None

        return {
            "molecule":         final.molecule_name,
            "smiles":           final.smiles,
            "total_iterations": result.total_iterations,
            "passed":           result.passed,
            "before":           self._summary(initial, c_init),
            "after":            self._summary(final,   c_final),
            "delta":            self._delta(initial, final),
        }

    # ── Private ───────────────────────────────────────────────────────────────

    def _summary(self, route: SynthesisRoute, critique: CriticFeedback | None) -> dict:
        steps = []
        for s in route.steps:
            # Fix 6: prefer the step's own green_score if already set by Critic
            score = s.green_score if s.green_score >= 0 else _step_score(s.solvent)
            steps.append({
                "step":        s.step,
                "reaction":    s.reaction_name,
                "solvent":     s.solvent,
                "green_score": score,
                "hazard":      SOLVENT_DB.get(s.solvent.lower(), {}).get("hazard", "unknown"),
            })
        return {
            "iteration":           route.iteration,
            "overall_green_score": route.overall_green_score,
            "pmi":                 route.pmi,
            "steps":               steps,
            "critic_summary":      critique.feedback_summary if critique else None,
            "issues_count":        len(critique.issues)      if critique else 0,
        }

    def _delta(self, before: SynthesisRoute, after: SynthesisRoute) -> dict:
        score_before = before.overall_green_score if before.overall_green_score >= 0 else 0
        score_after  = after.overall_green_score  if after.overall_green_score  >= 0 else 0

        improved = []
        for s_b, s_a in zip(before.steps, after.steps):
            if s_b.solvent.lower() != s_a.solvent.lower():
                sb = s_b.green_score if s_b.green_score >= 0 else _step_score(s_b.solvent)
                sa = s_a.green_score if s_a.green_score >= 0 else _step_score(s_a.solvent)
                improved.append({
                    "step":         s_b.step,
                    "before":       s_b.solvent,
                    "after":        s_a.solvent,
                    "score_before": sb,
                    "score_after":  sa,
                    "delta":        sa - sb,
                })

        pmi_b   = before.pmi or 0.0
        pmi_a   = after.pmi  or 0.0
        pmi_pct = round((pmi_b - pmi_a) / pmi_b * 100, 1) if pmi_b > 0 else 0.0

        return {
            "green_score":        round(score_after - score_before, 1),
            "pmi_reduction_pct":  pmi_pct,
            "steps_changed":      len(improved),
            "solvents_improved":  improved,
        }
