"""
Schema Module
-------------
Parses input SMILES and builds a structured molecular representation.
Uses RDKit for chemical validity and property extraction.
"""
from __future__ import annotations
from rdkit import Chem
from rdkit.Chem import Descriptors, rdMolDescriptors
from modules.models import ValidityReport


class SchemaModule:
    """
    Converts a raw SMILES string into a validated molecular schema.
    This is the entry point for the entire pipeline.
    """

    def parse(self, smiles: str) -> ValidityReport:
        """
        Validate and parse a SMILES string.

        Args:
            smiles: Input SMILES string from user

        Returns:
            ValidityReport with molecule properties or error details
        """
        smiles = smiles.strip()

        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return ValidityReport(
                smiles=smiles,
                is_valid=False,
                error=f"RDKit could not parse SMILES: '{smiles}'. "
                      f"Please check the input format."
            )

        # Sanitize and get canonical form
        try:
            Chem.SanitizeMol(mol)
            canonical = Chem.MolToSmiles(mol)
            formula = rdMolDescriptors.CalcMolFormula(mol)
            mw = round(Descriptors.MolWt(mol), 2)

            return ValidityReport(
                smiles=smiles,
                is_valid=True,
                sanitized_smiles=canonical,
                molecular_formula=formula,
                molecular_weight=mw,
            )

        except Exception as e:
            return ValidityReport(
                smiles=smiles,
                is_valid=False,
                error=f"Sanitization failed: {e}"
            )
