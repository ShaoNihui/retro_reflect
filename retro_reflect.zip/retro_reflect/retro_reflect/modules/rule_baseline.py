"""
Rule-Based Weak Baseline
------------------------
Deterministic solvent-substitution baseline. No LLM calls.

Schema contract (Problem 2 fix):
  The PipelineResult returned here is IDENTICAL in structure to the one
  returned by pipeline.run_pipeline(). Every field is populated with the
  same semantics so Comparator, experiments.py, and JSON export all work
  without branching on result source.

  Key alignment points:
    - route_validity is always set (RouteValidityReport, not None)
    - reflection_diffs uses the same ReflectionDiff schema as Reflector
    - critique_history uses CriticFeedback with passed computed by the same
      formula as CriticModule (PASS_MIN_STEP=5, PASS_MIN_MEAN=7)
    - final_green_score = critique_history[-1].overall_score (same as pipeline)
    - iteration numbering starts at 1 (same as pipeline)
"""
from __future__ import annotations
import copy
from typing import Optional
from modules.models import (
    SynthesisRoute, ReactionStep, CriticFeedback, CriticIssue,
    PipelineResult, ExperimentConfig, ReflectionDiff, SolventReplacement,
    RouteValidityReport, StepValidityReport,
    smiles_run_id,
)
from data.solvent_db import SOLVENT_DB

# Must match CriticModule.PASS_MIN_STEP and PASS_MIN_MEAN exactly
PASS_MIN_STEP = 5
PASS_MIN_MEAN = 7

# Reuse the same alias table as CriticModule so full names (dimethylformamide,
# tetrahydrofuran, etc.) resolve to their correct SOLVENT_DB keys.
# Imported lazily to avoid circular import at module load time.
def _get_aliases() -> dict:
    from modules.critic import SOLVENT_ALIASES
    return SOLVENT_ALIASES


# ── Internal helpers (same formula as CriticModule) ───────────────────────────

def _db_score(solvent: str) -> tuple[int, str, str | None]:
    key = solvent.lower().strip()
    # 1. Exact match
    if key in SOLVENT_DB:
        e = SOLVENT_DB[key]
        return e["score"], e["hazard"], e.get("alt")
    # 2. Alias normalisation (same mapping as CriticModule)
    aliases = _get_aliases()
    canonical = aliases.get(solvent, aliases.get(key, key)).lower().strip()
    if canonical in SOLVENT_DB:
        e = SOLVENT_DB[canonical]
        return e["score"], e["hazard"], e.get("alt")
    # 3. Compound "or" strings (e.g. "THF or ethyl acetate"): score as minimum of
    #    individual alternatives — pessimistic / conservative rule-based interpretation.
    if " or " in key:
        parts = [p.strip() for p in key.split(" or ")]
        scores = [_db_score(p)[0] for p in parts]
        min_score = min(scores)
        return min_score, f"compound alt solvent (worst component: {min_score}/10)", None
    # 4. No match
    return 6, "unknown solvent", None


def _score_route(route: SynthesisRoute) -> tuple[int, list[CriticIssue]]:
    """
    Score route in-place. Returns (overall_score, issues).
    Formula: int(sum / n) — identical to CriticModule.
    """
    issues: list[CriticIssue] = []
    total = 0
    for step in route.steps:
        score, hazard, alt = _db_score(step.solvent)
        step.green_score  = score
        step.score_reason = hazard
        total += score
        if score < PASS_MIN_STEP:
            # Use the full alt string from SOLVENT_DB (may be "X or Y").
            # _db_score has no partial matching, so compound strings score as 6
            # (unknown-solvent fallback) — conservative and consistent with DB design.
            suggestion = alt if alt else "ethyl acetate"
            issues.append(CriticIssue(
                step=step.step,
                problem=hazard,
                suggestion=suggestion,
            ))
    overall = int(total / len(route.steps)) if route.steps else 0
    route.overall_green_score = overall
    route.pmi = _estimate_pmi(route.steps)
    return overall, issues


def _estimate_pmi(steps: list) -> float:
    base    = 8.0
    penalty = sum(
        (10 - SOLVENT_DB.get(s.solvent.lower(), {}).get("score", 6)) * 0.4
        for s in steps
    )
    return round(base + penalty - len(steps) * 0.3, 1)


def _make_validity_report(route: SynthesisRoute) -> RouteValidityReport:
    """
    Produce a minimal RouteValidityReport for schema alignment.
    Rule baseline does not run RDKit — solvents are known-good from SOLVENT_DB.
    Any solvent not in DB is flagged as a blocking issue (same as ValidityCheckModule).
    """
    from modules.validity_check import KNOWN_SOLVENTS as KNOWN
    step_reports = []
    blocking = []
    for step in route.steps:
        ok = step.solvent.lower().strip() in KNOWN
        if not ok:
            blocking.append(f"Step {step.step}: unrecognized solvent '{step.solvent}'")
        step_reports.append(StepValidityReport(
            step=step.step,
            reagents_valid=ok,
            issues=[] if ok else [f"Unrecognized solvent '{step.solvent}'"],
        ))
    return RouteValidityReport(
        route_chemically_valid=not blocking,
        step_reports=step_reports,
        blocking_issues=blocking,
    )


def _make_critique(score: int, issues: list[CriticIssue], summary: str) -> CriticFeedback:
    """
    Build CriticFeedback using the same pass logic as CriticModule.
    """
    passed = (
        score >= PASS_MIN_MEAN
        and all(i.step == -1 for i in issues)  # issues list empty means all steps ok
    )
    # simpler: passed iff no issues AND score >= threshold
    passed = score >= PASS_MIN_MEAN and not issues
    return CriticFeedback(
        passed=passed,
        overall_score=score,
        issues=issues,
        feedback_summary=summary,
    )


# ── Template route (fallback when no Planner output is available) ─────────────

def _make_template_route(smiles: str) -> SynthesisRoute:
    """
    Create a minimal route without LLM for single-molecule testing.
    Uses common hazardous solvents so SOLVENT_DB substitution has work to do.

    NOTE: for paper-quality results all three conditions should share the same
    Planner-generated routes.  Use run_rule_baseline_batch.py for batch runs —
    it loads pre-computed routes from the no_reflection log (zero LLM calls).
    """
    try:
        from rdkit import Chem
        mol = Chem.MolFromSmiles(smiles)
        n_steps = max(2, min(5, mol.GetNumHeavyAtoms() // 8)) if mol else 3
    except Exception:
        n_steps = 3

    # Representative hazardous solvents that SOLVENT_DB can substitute
    defaults = ["dichloromethane", "toluene", "dimethylformamide", "dioxane"]
    return SynthesisRoute(
        molecule_name=smiles[:30],
        smiles=smiles,
        steps=[
            ReactionStep(
                step=i + 1,
                reaction_name=f"Reaction {i + 1}",
                reagents=[],
                solvent=defaults[i % len(defaults)],
                conditions="room temperature",
            )
            for i in range(n_steps)
        ],
    )


# ── Public API ────────────────────────────────────────────────────────────────

def run_rule_baseline(
    initial_route: Optional[SynthesisRoute],
    smiles: str,
) -> PipelineResult:
    """
    initial_route=None  →  uses _make_template_route() (single-molecule testing).
    For batch experiments, pass the Planner-generated route from the
    no_reflection run via run_rule_baseline_batch.py.
    """
    if initial_route is None:
        initial_route = _make_template_route(smiles)
    """
    Apply rule-based solvent substitution to initial_route.

    Schema contract: returns a PipelineResult structurally identical to
    pipeline.run_pipeline() output — all fields populated, same semantics.

    Args:
        initial_route: From PlannerModule.generate() — shared with other modes
                       so generation quality is held constant across conditions.
        smiles:        Original input SMILES (used for config and run_id).
    """
    config = ExperimentConfig(
        run_id=smiles_run_id(smiles, prefix="rule"),   # Fix 1: hash-based
        smiles=smiles,
        use_reflection=False,
        use_rule_baseline=True,
        notes="rule-based weak baseline: DB-lookup solvent substitution, no LLM",
    )

    # ── Iteration 1: score initial route ─────────────────────────────────────
    initial = copy.deepcopy(initial_route)
    initial.iteration = 1
    initial_score, initial_issues = _score_route(initial)
    initial_validity = _make_validity_report(initial)

    initial_critique = _make_critique(
        score=initial_score,
        issues=initial_issues,
        summary=(
            "Rule baseline initial scoring. Issues: "
            + ("; ".join(f"step {i.step}: {i.problem}" for i in initial_issues)
               if initial_issues else "none")
        ),
    )

    # Already passes — return single-iteration result
    if initial_critique.passed:
        return PipelineResult(
            config=config,
            smiles=smiles,
            total_iterations=1,
            final_route=initial,
            iteration_history=[initial],
            critique_history=[initial_critique],
            reflection_diffs=[],           # schema: empty list, not missing field
            route_validity=initial_validity,
            passed=True,
            final_green_score=initial_score,   # = critique_history[-1].overall_score
        )

    # ── Iteration 2: apply DB substitutions ──────────────────────────────────
    revised = copy.deepcopy(initial)
    revised.iteration        = 2
    revised.validity_blocked = False

    replacements: list[SolventReplacement] = []
    for issue in initial_issues:
        idx  = issue.step - 1
        step = revised.steps[idx]
        orig = step.solvent
        new  = issue.suggestion
        if orig.lower() == new.lower():
            continue                       # DB has no better alt — keep as-is
        step.solvent      = new
        step.green_score  = -1             # reset; _score_route will fill
        step.score_reason = ""
        replacements.append(SolventReplacement(
            step=issue.step,
            original_solvent=orig,
            replacement_solvent=new,
            reason=issue.problem,
        ))

    revised_score, revised_issues = _score_route(revised)
    revised_validity = _make_validity_report(revised)

    revised_critique = _make_critique(
        score=revised_score,
        issues=revised_issues,
        summary=(
            f"After rule substitution: score={revised_score}/10. "
            + ("Passed." if not revised_issues
               else f"{len(revised_issues)} issue(s) remain — DB has no greener alternative.")
        ),
    )

    diff = ReflectionDiff(
        iteration_from=1,
        iteration_to=2,
        permitted_changes=replacements,
        rejected_changes=[],   # rule baseline never rejects — it either swaps or skips
    )

    return PipelineResult(
        config=config,
        smiles=smiles,
        total_iterations=2,
        final_route=revised,
        iteration_history=[initial, revised],
        critique_history=[initial_critique, revised_critique],
        reflection_diffs=[diff],
        route_validity=revised_validity,
        passed=revised_critique.passed,
        final_green_score=revised_score,   # = critique_history[-1].overall_score ✓
    )
