"""
Reflector Module  (Fix 4: split from Planner)
---------------------------------------------
Decides WHAT to change based on CriticFeedback, then instructs PlannerModule
to execute only those changes.

Responsibilities:
  - Interpret CriticFeedback and build an ordered list of SolventReplacements
  - Call planner.apply_replacements() with the constrained change list
  - Enforce that no non-solvent field is modified (hard constraint in code)
  - Return (revised_route, ReflectionDiff) as an auditable pair

PlannerModule is now purely generative: generate() and apply_replacements().
Reflector owns all reflection logic and the diff audit trail.
"""
from __future__ import annotations
import copy
from modules.models import (
    SynthesisRoute, CriticFeedback,
    ReflectionDiff, SolventReplacement,
)


class ReflectorModule:
    """
    Fix 4: Reflection decision logic, fully decoupled from Planner.

    Design principle: Reflector knows what to change; Planner knows how to
    generate. Keeping them separate makes both independently testable and
    makes the paper's architecture diagram honest.
    """

    def reflect(
        self,
        route:     SynthesisRoute,
        feedback:  CriticFeedback,
        iteration: int,
        planner,                    # PlannerModule — injected to avoid circular import
    ) -> tuple[SynthesisRoute, ReflectionDiff]:
        """
        Produce a revised route by applying only the solvent replacements
        mandated by CriticFeedback.

        Args:
            route:     Current route (from previous iteration)
            feedback:  CriticFeedback from CriticModule
            iteration: Target iteration number for the revised route
            planner:   PlannerModule instance (used only for apply_replacements)

        Returns:
            (revised_route, diff) where diff is a full audit trail
        """
        if not feedback.issues:
            # Nothing to fix — clone with updated iteration number
            revised = copy.deepcopy(route)
            revised.iteration = iteration
            diff = ReflectionDiff(
                iteration_from=iteration - 1,
                iteration_to=iteration,
                permitted_changes=[],
                rejected_changes=[],
            )
            return revised, diff

        # ── Build replacement plan from Critic issues ─────────────────────────
        replacements: list[SolventReplacement] = []
        for issue in feedback.issues:
            if issue.step < 1 or issue.step > len(route.steps):
                continue
            original_solvent = route.steps[issue.step - 1].solvent
            if original_solvent.lower() == issue.suggestion.lower():
                continue   # already correct — Critic hallucinated the issue
            replacements.append(SolventReplacement(
                step=issue.step,
                original_solvent=original_solvent,
                replacement_solvent=issue.suggestion,
                reason=issue.problem,
            ))

        # ── Delegate execution to Planner ─────────────────────────────────────
        revised, rejected = planner.apply_replacements(route, replacements, iteration)

        diff = ReflectionDiff(
            iteration_from=iteration - 1,
            iteration_to=iteration,
            permitted_changes=replacements,
            rejected_changes=rejected,
        )
        return revised, diff
