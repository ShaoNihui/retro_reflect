"""
ValidityCheck Module
--------------------
Fix 3: has_blocking_issues now causes pipeline to mark route as validity_blocked=True,
which forces re-plan (or hard stop if max_iter reached). Not just a warning.
"""
from __future__ import annotations
from rdkit import Chem
from modules.models import SynthesisRoute, RouteValidityReport, StepValidityReport

INCOMPATIBLE_PAIRS: list[tuple[str, str, str]] = [
    ("water",   "grignard",       "Grignard reagents destroyed by protic solvents"),
    ("water",   "organolithium",  "Organolithium reagents react violently with water"),
    ("water",   "sodium hydride", "NaH reacts violently with water"),
    ("water",   "acyl chloride",  "Acyl chlorides hydrolyze instantly in water"),
    ("ethanol", "sodium hydride", "NaH reacts with protic solvents"),
    ("methanol","sodium hydride", "NaH reacts with protic solvents"),
    ("dmf",     "strong base",    "DMF can hydrolyze under strongly basic conditions"),
]

KNOWN_SOLVENTS: frozenset[str] = frozenset({
    # Water & alcohols
    "water", "ethanol", "methanol", "isopropanol", "propanol",
    "tert-butanol", "tert butanol", "t-butanol", "n-butanol", "butanol",
    # Ketones & esters
    "acetone", "methyl ethyl ketone", "mek", "ethyl acetate", "butyl acetate",
    # Nitriles & amides
    "acetonitrile", "dmf", "dimethylformamide", "dmso", "dimethyl sulfoxide",
    "nmp", "n-methyl-2-pyrrolidone", "dma", "dimethylacetamide",
    # Ethers
    "thf", "tetrahydrofuran", "2-methylthf", "2-methythf",
    "2-methyltetrahydrofuran", "2-methyl tetrahydrofuran", "2-mthf", "dme", "dioxane", "1,4-dioxane",
    "diethyl ether", "ether", "methyl tert-butyl ether", "mtbe",
    # Chlorinated
    "dichloromethane", "dcm", "chloroform", "carbon tetrachloride",
    "1,2-dichloroethane", "chlorobenzene",
    # Aromatics & hydrocarbons
    "toluene", "benzene", "xylene", "xylenes", "mesitylene",
    "hexane", "heptane", "cyclohexane", "pentane",
    # Polar special
    "acetic acid", "nitromethane", "nitrobenzene", "anisole",
    "dimethyl carbonate", "quinoline", "pyridine",
    # Inorganic acids (used as catalysts/reagents, not true solvents)
    "sulfuric acid", "hydrochloric acid", "phosphoric acid",
    "hydrobromic acid", "nitric acid", "acetic anhydride",
    # Bases commonly listed as solvent/medium
    "triethylamine", "tea", "diisopropylethylamine", "dipea", "hunigs base",
    "sodium hydroxide", "potassium hydroxide", "ammonia",
    # Misc
    "none", "neat", "solvent-free", "no solvent",
    "ethylene glycol", "glycerol", "propylene glycol",
    "diglyme", "1,2-dimethoxyethane",
    # Extended: CPME & green esters
    "cpme", "cyclopentyl methyl ether",
    "isopropyl acetate", "iprOAc", "ipac",
    # Extended: alcohols
    "2-butanol", "sec-butanol", "s-butanol",
    "isobutanol", "2-methyl-1-propanol",
    "n-propanol", "1-propanol",
    # Extended: ketones
    "cyclopentanone",
    # Extended: alkanes
    "hexane", "n-hexane", "n-pentane", "n-heptane",
    # Extended: chlorinated
    "1,2-dichloroethane", "ethylene dichloride", "dce",
    # Extended: aromatics
    "methoxybenzene", "nitrobenzene", "chlorobenzene",
    # Extended: ethers
    "2-methoxyethyl ether", "1,2-dimethoxyethane",
    "methyl tert-butyl ether", "mtbe", "tert-butyl methyl ether",
    # Extended: polyols
    "1,2-propanediol", "1,2-ethanediol",
    # Extended: esters
    "butyl acetate",
})


class ValidityCheckModule:

    def validate(self, route: SynthesisRoute) -> RouteValidityReport:
        """
        Fix 3: Returns RouteValidityReport.
        Pipeline must check has_blocking_issues and set route.validity_blocked=True.
        """
        step_reports: list[StepValidityReport] = []
        blocking: list[str] = []

        if len(route.steps) > 8:
            blocking.append(
                f"Route has {len(route.steps)} steps — "
                "unusually long, likely hallucinated. Max expected: 6."
            )

        for step in route.steps:
            issues:         list[str] = []
            reagents_valid: bool      = True

            # Unknown solvent
            from modules.critic import normalize_solvent
            from data.solvent_db import SOLVENT_DB as _SOLVENT_DB
            normalized = normalize_solvent(step.solvent)
            if normalized not in _SOLVENT_DB and step.solvent.lower().strip() not in KNOWN_SOLVENTS:
                msg = f"Unrecognized solvent '{step.solvent}'"
                issues.append(msg)
                blocking.append(f"Step {step.step}: {msg}")
                reagents_valid = False

            # Reagent SMILES validity
            for reagent in step.reagents:
                if self._looks_like_smiles(reagent):
                    if Chem.MolFromSmiles(reagent) is None:
                        msg = f"Invalid reagent SMILES: '{reagent}'"
                        issues.append(msg)
                        reagents_valid = False

            # Incompatible pairs
            solvent_key = step.solvent.lower()
            for sol_pat, reagent_pat, reason in INCOMPATIBLE_PAIRS:
                if sol_pat in solvent_key:
                    for reagent in step.reagents:
                        if reagent_pat in reagent.lower():
                            blocking.append(f"Step {step.step}: {reason}")
                            issues.append(reason)

            step_reports.append(StepValidityReport(
                step=step.step,
                reagents_valid=reagents_valid and not issues,
                issues=issues,
            ))

        route_valid = not blocking and all(r.reagents_valid for r in step_reports)
        return RouteValidityReport(
            route_chemically_valid=route_valid,
            step_reports=step_reports,
            blocking_issues=blocking,
        )

    @staticmethod
    def _looks_like_smiles(s: str) -> bool:
        has_smiles_char = any(c in s for c in "=#@")
        return has_smiles_char and sum(1 for c in s if c in "()[]=#@") >= 2 and len(s) > 3
