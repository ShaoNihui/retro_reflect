"""
Planner Module  (Fix 4: generate + apply_replacements only)
------------------------------------------------------------
Purely generative. Does NOT own reflection logic (see ReflectorModule).

Two public methods:
  generate()            — LLM call to produce an initial route
  apply_replacements()  — deterministic solvent swap (no LLM call)
"""
from __future__ import annotations
import copy
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from modules.models import (
    SynthesisRoute, ReactionStep, SolventReplacement,
)

PLANNER_SYSTEM = """You are an expert organic chemist specialising in retrosynthetic analysis.
Design practical 3–4 step synthesis routes for pharmaceutical molecules.

For each step specify:
- A real named reaction (Fischer esterification, Suzuki coupling, Friedel-Crafts, etc.)
- All reagents as a list of common chemical names
- The solvent as a single lowercase name, chosen based on standard practice for that
  specific reaction type in the chemical literature
- Reaction conditions (temperature, time, atmosphere)

Output valid JSON only. No markdown, no extra text."""

PLANNER_HUMAN = """Design a retrosynthetic route.

Target: {molecule_name}
SMILES: {smiles}
Formula: {formula}  MW: {mw} g/mol

Return JSON exactly:
{{
  "molecule_name": "{molecule_name}",
  "smiles": "{smiles}",
  "steps": [
    {{
      "step": 1,
      "reaction_name": "<named reaction>",
      "reagents": ["<reagent1>", "<reagent2>"],
      "solvent": "<solvent lowercase>",
      "conditions": "<temp, time, atmosphere>"
    }}
  ]
}}"""

KNOWN_MOLECULES = {
    "CC(=O)Oc1ccccc1C(=O)O":          "Aspirin",
    "CC(C)Cc1ccc(cc1)C(C)C(=O)O":     "Ibuprofen",
    "CN1CCC[C@H]1c2cccnc2":            "Nicotine",
    "O=C(O)c1ccccc1O":                 "Salicylic acid",
    "c1ccc2c(c1)cc1ccc3cccc4ccc2c1c34":"Pyrene",
}


class PlannerModule:
    """
    Fix 4: Planner is purely generative.
    Reflection decisions are made by ReflectorModule; Planner only executes them.
    """

    def __init__(self, llm):
        """
        Args:
            llm: LangChain chat model dedicated to Planner (independent of Critic).
        """
        self.llm = llm
        self._chain = (
            ChatPromptTemplate.from_messages([
                ("system", PLANNER_SYSTEM),
                ("human",  PLANNER_HUMAN),
            ])
            | self.llm
            | JsonOutputParser()
        )

    def generate(self, validity_report, iteration: int = 1) -> SynthesisRoute:
        """LLM-based initial route generation."""
        smiles = validity_report.sanitized_smiles or validity_report.smiles
        raw = self._chain.invoke({
            "molecule_name": KNOWN_MOLECULES.get(smiles, "Target Molecule"),
            "smiles":        smiles,
            "formula":       validity_report.molecular_formula or "unknown",
            "mw":            validity_report.molecular_weight  or 0,
        })
        return self._parse(raw, iteration)

    def apply_replacements(
        self,
        route:        SynthesisRoute,
        replacements: list[SolventReplacement],
        iteration:    int,
    ) -> tuple[SynthesisRoute, list[str]]:
        """
        Deterministic solvent swap — NO LLM call.
        Returns (revised_route, list_of_rejected_reasons).

        Fix 4 / Fix 6: only the solvent field is ever modified here.
        reaction_name, reagents, and conditions are copied verbatim.
        """
        revised   = copy.deepcopy(route)
        revised.iteration = iteration
        revised.overall_green_score = -1   # reset — Critic will re-score
        revised.pmi                 = 0.0

        rejected: list[str] = []
        swap_map  = {r.step: r for r in replacements}

        for step in revised.steps:
            if step.step not in swap_map:
                continue
            rep = swap_map[step.step]
            # Validate the replacement is actually different
            if step.solvent.lower() == rep.replacement_solvent.lower():
                rejected.append(
                    f"Step {step.step}: replacement solvent "
                    f"'{rep.replacement_solvent}' is same as current — skipped."
                )
                continue
            step.solvent      = rep.replacement_solvent
            step.green_score  = -1    # reset so Critic re-scores fresh
            step.score_reason = ""

        return revised, rejected

    # ── Private ───────────────────────────────────────────────────────────────

    def _parse(self, raw: dict, iteration: int) -> SynthesisRoute:
        steps = [
            ReactionStep(
                step=s["step"],
                reaction_name=s["reaction_name"],
                reagents=s.get("reagents", []),
                solvent=s["solvent"],
                conditions=s.get("conditions", ""),
            )
            for s in raw.get("steps", [])
        ]
        return SynthesisRoute(
            molecule_name=raw.get("molecule_name", "Unknown"),
            smiles=raw.get("smiles", ""),
            steps=steps,
            iteration=iteration,
        )