"""
Critic Module — Enhanced Version
---------------------------------
Improvements:
1. Solvent alias normalization (EtOAc, DCM, MeOH → canonical names)
2. Unknown solvents get conservative low score (3, not 6)
3. neat/solvent-free correctly scored as 8 (not mapped to water)
4. Mandatory scan: all steps with score < PASS_MIN_STEP are flagged
5. PMI reuses already-computed step_scores for consistency
"""
from __future__ import annotations
import json
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from modules.models import SynthesisRoute, CriticFeedback, CriticIssue
from data.solvent_db import SOLVENT_DB

SOLVENT_ALIASES: dict[str, str] = {
    # Esters
    "etOAc":              "ethyl acetate",
    "AcOEt":              "ethyl acetate",
    # Alcohols
    "EtOH":               "ethanol",
    "MeOH":               "methanol",
    "iPrOH":              "isopropanol",
    "i-PrOH":             "isopropanol",
    "isopropyl alcohol":  "isopropanol",
    "tBuOH":              "tert-butanol",
    "t-BuOH":             "tert-butanol",
    "tert-butyl alcohol": "tert-butanol",
    # Chlorinated
    "DCM":                "dcm",
    "CH2Cl2":             "dcm",
    "methylene chloride": "dcm",
    "CHCl3":              "chloroform",
    "CCl4":               "carbon tetrachloride",
    # Ethers
    "THF":                "thf",
    "tetrahydrofuran":    "thf",
    "Et2O":               "dme",           # diethyl ether not in DB → dme (similar class)
    "ether":              "dme",
    "diethylether":       "dme",
    "diethyl ether":      "dme",
    "2-MeTHF":            "2-methylthf",
    "2-methylTHF":        "2-methylthf",
    "2-methyl-THF":       "2-methylthf",
    "mTHF":               "2-methylthf",
    "dioxane":            "dioxane",
    "1,4-dioxane":        "dioxane",
    # Amides / polar aprotic
    "DMF":                "dmf",
    "dimethylformamide":  "dmf",
    "DMA":                "dmf",           # dimethylacetamide → dmf (similar hazard)
    "dimethylacetamide":  "dmf",
    "NMP":                "dmf",           # NMP not in DB → dmf (similar class)
    "DMSO":               "dmso",
    "dimethyl sulfoxide": "dmso",
    # Nitriles
    "MeCN":               "acetonitrile",
    "ACN":                "acetonitrile",
    # Aromatics
    "PhMe":               "toluene",
    "PhH":                "benzene",
    "xylenes":            "xylene",
    # Ketones
    "MEK":                "acetone",       # methyl ethyl ketone → acetone (similar score)
    "methyl ethyl ketone":"acetone",
    # Carbonates
    "DMC":                "dimethyl carbonate",
    # Water / acids
    "H2O":                "water",
    "AcOH":               "acetic acid",
    # Solvent-free
    "neat":               "neat",
    "solvent-free":       "solvent-free",
    "no solvent":         "no solvent",
    # 2-MeTHF variants
    "2-methyltetrahydrofuran":  "2-methylthf",
    "2-methyl-tetrahydrofuran": "2-methylthf",
    # CPME
    "CPME":               "cyclopentyl methyl ether",
    "cpme":               "cyclopentyl methyl ether",
    # MTBE
    "MTBE":               "mtbe",
    "tert-butyl methyl ether": "mtbe",
    # Isopropyl acetate
    "iPrOAc":             "isopropyl acetate",
    "IPAc":               "isopropyl acetate",
    # Chlorinated
    "DCE":                "1,2-dichloroethane",
    "ethylene dichloride": "1,2-dichloroethane",
    "EDC":                "1,2-dichloroethane",
    # Ethers
    "2-methoxyethyl ether": "diglyme",
    "DME":                "1,2-dimethoxyethane",
    # Aromatics
    "methoxybenzene":     "anisole",
    "PhOMe":              "anisole",
    # Nitro
    "MeNO2":              "nitromethane",
    # Alcohols
    "sec-butanol":        "2-butanol",
    "s-BuOH":             "2-butanol",
    "2-methyl-1-propanol": "isobutanol",
    "i-BuOH":             "isobutanol",
    "iBuOH":              "isobutanol",
    "n-BuOH":             "n-butanol",
    # Alkanes
    "n-hexane":           "hexane",
    "n-heptane":          "heptane",
    "n-pentane":          "pentane",
    # Polyols
    "1,2-propanediol":    "propylene glycol",
    "1,2-ethanediol":     "ethylene glycol",
    "EG":                 "ethylene glycol",
    # Misc
    "n-propanol":         "propanol",
    "1-propanol":         "propanol",
    "EtOH":               "ethanol",
}


def normalize_solvent(raw: str) -> str:
    """
    Normalize solvent name:
    1. Strip parenthetical notes: "water (5% EtOH)" -> "water"
    2. Take primary solvent from mixtures: "DCM/MeOH" -> "DCM"
    3. Remove common adjectives: "anhydrous THF" -> "THF"
    4. Exact alias match (case-insensitive)
    5. Partial alias match as fallback
    """
    import re
    s = raw.strip()
    # Remove parenthetical notes
    s = re.sub(r"\(.*?\)", "", s).strip()
    # Take primary solvent from mixtures (split on / : ,)
    s = re.split(r"[/,:]", s)[0].strip()
    # Remove common adjectives and trailing additives
    for adj in ["anhydrous", "dry", "abs.", "absolute", "aqueous", "aq."]:
        s = re.sub(rf"(?i)^{adj}\s+", "", s).strip()
    # Remove "with <additive>" anywhere in string
    s = re.sub(r"(?i)\s+with\s+\S+", "", s).strip()
    # Exact match
    for alias, canonical in SOLVENT_ALIASES.items():
        if s.lower() == alias.lower():
            return canonical.lower()
    # Partial match (alias contained in s)
    for alias, canonical in SOLVENT_ALIASES.items():
        if alias.lower() in s.lower():
            return canonical.lower()
    return s.lower()


CRITIC_SYSTEM = """You are a strict green chemistry auditor (ACS GCI principles).
You are INDEPENDENT from the chemist who designed the route.

ACS GCI solvent scores:
  0-2 banned/highly hazardous | 3-4 hazardous | 5-6 acceptable | 7-8 recommended | 9-10 ideal

A route PASSES only when ALL step solvent scores >= 5 AND mean >= 7.
Output valid JSON only. No markdown, no extra text."""

CRITIC_HUMAN = """Evaluate this synthesis route:

Molecule: {molecule_name}  SMILES: {smiles}

Steps (with pre-computed DB scores):
{steps_json}

Return JSON exactly:
{{
  "issues": [
    {{
      "step": <int>,
      "problem": "<specific ACS GCI hazard>",
      "suggestion": "<replacement solvent lowercase>"
    }}
  ],
  "feedback_summary": "<one sentence: which steps need fixing and what to use>"
}}

List EVERY step whose solvent score < 5 as an issue.
Do NOT include a passed or overall_score field."""


class CriticModule:

    PASS_MIN_STEP = 5
    PASS_MIN_MEAN = 7
    UNKNOWN_SCORE = 3

    def __init__(self, llm):
        self.llm = llm
        self._chain = (
            ChatPromptTemplate.from_messages([
                ("system", CRITIC_SYSTEM),
                ("human",  CRITIC_HUMAN),
            ])
            | self.llm
            | JsonOutputParser()
        )

    def evaluate(self, route: SynthesisRoute) -> CriticFeedback:
        # 1. Normalize solvents & score from DB
        step_scores: dict[int, int] = {}
        unknown_solvents: list[str] = []

        for step in route.steps:
            normalized = normalize_solvent(step.solvent)
            step.solvent = normalized
            score, reason, is_unknown = self._db_score(normalized)
            step.green_score  = score
            step.score_reason = reason
            step_scores[step.step] = score
            if is_unknown:
                unknown_solvents.append(f"step {step.step}: '{normalized}'")

        # 2. Aggregate metrics
        scores        = list(step_scores.values())
        overall_score = int(sum(scores) / len(scores)) if scores else 0
        passed        = (
            overall_score >= self.PASS_MIN_MEAN
            and all(s >= self.PASS_MIN_STEP for s in scores)
        )

        route.overall_green_score = overall_score
        route.pmi = self._estimate_pmi(route.steps, step_scores)

        # 3. Ask LLM for issue descriptions
        steps_with_scores = [
            {**s.model_dump(),
             "db_score":  step_scores[s.step],
             "db_reason": s.score_reason}
            for s in route.steps
        ]
        try:
            raw = self._chain.invoke({
                "molecule_name": route.molecule_name,
                "smiles":        route.smiles,
                "steps_json":    json.dumps(steps_with_scores, indent=2),
            })
        except Exception:
            raw = {"issues": [], "feedback_summary": "LLM evaluation unavailable."}

        # 4. Mandatory scan: flag ALL steps with score < PASS_MIN_STEP
        issues: list[CriticIssue] = []
        for step in route.steps:
            sc = step_scores[step.step]
            if sc >= self.PASS_MIN_STEP:
                continue
            llm_issue = next(
                (i for i in raw.get("issues", [])
                 if isinstance(i, dict) and i.get("step") == step.step),
                None
            )
            if llm_issue:
                problem    = llm_issue.get("problem", step.score_reason)
                suggestion = llm_issue.get("suggestion", "ethyl acetate")
            else:
                problem    = f"{step.score_reason} (score {sc}/10)"
                db_entry   = SOLVENT_DB.get(step.solvent, {})
                suggestion = db_entry.get("alt") or "ethyl acetate"

            issues.append(CriticIssue(
                step=step.step,
                problem=problem,
                suggestion=suggestion,
            ))

        unknown_note = ""
        if unknown_solvents:
            unknown_note = f" Unrecognized solvents (scored conservatively at {self.UNKNOWN_SCORE}): {', '.join(unknown_solvents)}."

        return CriticFeedback(
            passed=passed,
            overall_score=overall_score,
            issues=issues,
            feedback_summary=raw.get("feedback_summary", "") + unknown_note,
        )

    def _db_score(self, solvent: str) -> tuple[int, str, bool]:
        key = solvent.lower().strip()
        if key in SOLVENT_DB:
            return SOLVENT_DB[key]["score"], SOLVENT_DB[key]["hazard"], False
        for k, v in SOLVENT_DB.items():
            if k in key or key in k:
                return v["score"], v["hazard"], False
        return self.UNKNOWN_SCORE, "unknown solvent, treated as hazardous (conservative)", True

    def _estimate_pmi(self, steps: list, step_scores: dict = None) -> float:
        """
        Simplified PMI proxy — not a true PMI calculation.
        Reuses step_scores for consistency with scoring module.
        """
        base = 8.0
        solvent_penalty = 0.0
        condition_penalty = 0.0

        for s in steps:
            if step_scores and s.step in step_scores:
                sc = step_scores[s.step]
            else:
                sc = SOLVENT_DB.get(s.solvent.lower(), {}).get("score", self.UNKNOWN_SCORE)
            solvent_penalty += (10 - sc) * 0.4
            cond = s.conditions.lower() if hasattr(s, "conditions") and s.conditions else ""
            if any(kw in cond for kw in ["reflux", "200", "250", "high pressure", "high temp"]):
                condition_penalty += 0.5

        step_discount = len(steps) * 0.3
        pmi = base + solvent_penalty + condition_penalty - step_discount
        return round(max(pmi, 3.0), 1)
