"""
Shared data models for Retro-Reflect pipeline.

Fix 6: Unified step-level schema — ReactionStep is the single source of truth.
       green_score is always int (never None after Critic runs).
       All modules (Critic, Reflector, Comparator) reference the same field names.
"""
from __future__ import annotations
import hashlib
from typing import Optional
from pydantic import BaseModel, Field


def smiles_run_id(smiles: str, prefix: str = "") -> str:
    """
    Stable, collision-free run identifier derived from SMILES.
    Uses first 12 hex chars of SHA-256 — unique enough for any realistic
    experiment set, human-readable in filenames and CSVs.

    Examples:
        smiles_run_id("CC(=O)Oc1ccccc1C(=O)O")          → "a3f1c82d9b04"
        smiles_run_id("CC(=O)Oc1ccccc1C(=O)O", "rule")  → "rule_a3f1c82d9b04"
    """
    digest = hashlib.sha256(smiles.encode()).hexdigest()[:12]
    return f"{prefix}_{digest}" if prefix else digest


# ── Core chemistry models ─────────────────────────────────────────────────────

class ReactionStep(BaseModel):
    """
    Single step in a synthesis route.
    Fix 6: green_score defaults to -1 (sentinel) so callers can distinguish
    'not yet scored' from a genuine 0. Never use None for scored steps.
    """
    step:          int
    reaction_name: str
    reagents:      list[str]
    solvent:       str
    conditions:    str
    green_score:   int  = Field(default=-1, ge=-1, le=10)  # -1 = not yet scored
    score_reason:  str  = ""                                # filled by Critic


class SynthesisRoute(BaseModel):
    molecule_name:       str
    smiles:              str
    steps:               list[ReactionStep]
    overall_green_score: int   = Field(default=-1)   # -1 = not yet scored; Fix 2
    pmi:                 float = Field(default=0.0)
    iteration:           int   = 1
    validity_blocked:    bool  = False               # Fix 3: set True if ValidityCheck rejects


class CriticIssue(BaseModel):
    step:       int
    problem:    str
    suggestion: str    # exact replacement solvent name in lowercase


class CriticFeedback(BaseModel):
    """
    Fix 1: passed is the ONLY exit criterion — no secondary score >= threshold check.
    passed is computed deterministically from overall_score and per-step scores
    inside CriticModule; pipeline.py must not re-interpret it.
    """
    passed:           bool
    overall_score:    int  = Field(ge=0, le=10)
    issues:           list[CriticIssue]
    feedback_summary: str


# ── Validity models ───────────────────────────────────────────────────────────

class StepValidityReport(BaseModel):
    step:            int
    reagents_valid:  bool
    issues:          list[str] = Field(default_factory=list)


class RouteValidityReport(BaseModel):
    """
    Fix 3: has_blocking_issues must cause pipeline to skip Critic
    and force re-plan (or terminate if max_iter reached).
    """
    route_chemically_valid: bool
    step_reports:           list[StepValidityReport]
    blocking_issues:        list[str] = Field(default_factory=list)

    @property
    def has_blocking_issues(self) -> bool:
        return bool(self.blocking_issues)


# ── Reflection models ─────────────────────────────────────────────────────────

class SolventReplacement(BaseModel):
    """Fix 4 / Fix 6: used by Reflector (not Planner) to record each change."""
    step:                 int
    original_solvent:     str
    replacement_solvent:  str
    reason:               str


class ReflectionDiff(BaseModel):
    """
    Fix 4: owned by Reflector, not Planner.
    Audit trail of permitted solvent swaps and blocked non-solvent changes.
    """
    iteration_from:    int
    iteration_to:      int
    permitted_changes: list[SolventReplacement]
    rejected_changes:  list[str] = Field(default_factory=list)


# ── Experiment / result models ────────────────────────────────────────────────

class ExperimentConfig(BaseModel):
    run_id:                str
    smiles:                str
    use_reflection:        bool  = True
    use_rule_baseline:     bool  = False   # Fix 5: run rule-based weak baseline
    max_iterations:        int   = 3
    green_score_threshold: int   = 7
    planner_model:         str   = "gpt-4o"
    critic_model:          str   = "claude-sonnet-4-5"
    notes:                 str   = ""


class ValidityReport(BaseModel):
    smiles:             str
    is_valid:           bool
    sanitized_smiles:   Optional[str]   = None
    molecular_formula:  Optional[str]   = None
    molecular_weight:   Optional[float] = None
    error:              Optional[str]   = None


class PipelineResult(BaseModel):
    config:             Optional[ExperimentConfig]    = None
    smiles:             str
    total_iterations:   int
    final_route:        SynthesisRoute
    iteration_history:  list[SynthesisRoute]
    critique_history:   list[CriticFeedback]
    reflection_diffs:   list[ReflectionDiff]          = Field(default_factory=list)
    route_validity:     Optional[RouteValidityReport] = None
    passed:             bool
    final_green_score:  int      # Fix 2: always = critique_history[-1].overall_score
