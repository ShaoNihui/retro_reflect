"""
Retro-Reflect Pipeline  (all 6 fixes applied)
----------------------------------------------
Fix 1: passed is the sole exit criterion — no score >= threshold shortcut
Fix 2: final_green_score = critique_history[-1].overall_score
Fix 3: ValidityCheck blocking issues set route.validity_blocked=True → re-plan
Fix 4: Reflector owns reflection; Planner only generates / applies_replacements
Fix 5: --rule-baseline flag runs RuleBaseline instead of LLM pipeline
Fix 6: ReactionStep.green_score is always int; single scoring formula throughout
"""
from __future__ import annotations
import os, json, argparse
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from modules.schema        import SchemaModule
from modules.validity_check import ValidityCheckModule
from modules.planner        import PlannerModule
from modules.critic         import CriticModule
from modules.reflector      import ReflectorModule
from modules.comparator     import ComparatorModule
from modules.rule_baseline  import run_rule_baseline
from modules.models         import PipelineResult, ExperimentConfig, smiles_run_id

load_dotenv()
console = Console()

MAX_VALIDITY_RETRIES = 2   # re-plans allowed when ValidityCheck blocks a route


def _build_llms():
    """Fix 1 / Fix 4: two independent LLM instances."""
    planner_model = os.getenv("PLANNER_MODEL", "gpt-4o")
    critic_model  = os.getenv("CRITIC_MODEL",  "claude-sonnet-4-5")

    def make(model, temp):
        if model.startswith("claude"):
            from langchain_anthropic import ChatAnthropic
            return ChatAnthropic(model=model, temperature=float(temp))
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=model, temperature=float(temp))

    return (
        make(planner_model, os.getenv("PLANNER_TEMPERATURE", "0.3")),
        make(critic_model,  os.getenv("CRITIC_TEMPERATURE",  "0.0")),
    )


def run_pipeline(
    smiles:         str,
    max_iter:       int  = 3,
    threshold:      int  = 7,
    use_reflection: bool = True,
    rule_baseline:  bool = False,   # Fix 5
) -> PipelineResult:

    # ── Schema (LLM-free, always runs first) ──────────────────────────────────
    schema = SchemaModule()
    console.rule("[bold blue]Schema")
    vr = schema.parse(smiles)
    if not vr.is_valid:
        raise ValueError(f"Invalid SMILES: {vr.error}")
    console.print(f"[green]✓[/green] {vr.molecular_formula}  MW={vr.molecular_weight}")

    # Fix 5 (corrected): rule baseline exits HERE — no LLM objects created,
    # no Planner call. Routes come from run_rule_baseline_batch.py which
    # reuses pre-computed Planner output from the no_reflection run.
    if rule_baseline:
        console.rule("[bold yellow]Rule-Based Baseline")
        return run_rule_baseline(None, smiles)

    # ── LLM setup — only reached for no_reflection / full_pipeline ────────────
    planner_llm, critic_llm = _build_llms()

    vc        = ValidityCheckModule()
    planner   = PlannerModule(planner_llm)
    critic    = CriticModule(critic_llm)
    reflector = ReflectorModule()            # Fix 4

    config = ExperimentConfig(
        run_id=smiles_run_id(smiles),
        smiles=smiles,
        use_reflection=use_reflection,
        use_rule_baseline=rule_baseline,
        max_iterations=max_iter,
        green_score_threshold=threshold,
        planner_model=os.getenv("PLANNER_MODEL", "gpt-4o"),
        critic_model =os.getenv("CRITIC_MODEL",  "claude-sonnet-4-5"),
    )

    # ── Initial generation ────────────────────────────────────────────────────
    console.rule("[bold cyan]Iteration 1 — Planner")
    route = planner.generate(vr, iteration=1)
    _print_route(route)

    # ── Reflexion loop ────────────────────────────────────────────────────────
    iteration_history = []
    critique_history  = []
    reflection_diffs  = []
    feedback          = None
    effective_max     = 1 if not use_reflection else max_iter
    validity_retries  = 0

    for iteration in range(1, effective_max + 1):
        if iteration > 1:
            console.rule(f"[bold cyan]Iteration {iteration}/{effective_max}")

        # Fix 3: ValidityCheck — blocking issues → re-plan, not just warn
        console.print("[purple]ValidityCheck[/purple] →")
        validity_report = vc.validate(route)

        if validity_report.has_blocking_issues:
            route.validity_blocked = True
            console.print(
                "[red]Blocking issues:[/red]\n"
                + "\n".join(f"  • {i}" for i in validity_report.blocking_issues)
            )
            if validity_retries < MAX_VALIDITY_RETRIES and iteration <= effective_max:
                validity_retries += 1
                console.print(f"[yellow]Re-planning (retry {validity_retries})…[/yellow]")
                route = planner.generate(vr, iteration=iteration)
                continue          # re-check validity before scoring
            else:
                console.print("[red]Max validity retries reached — proceeding with blocked route.[/red]")
        else:
            console.print("[green]✓[/green] No blocking issues")

        validity_retries = 0   # reset on clean route

        # Critic
        console.print("[yellow]Critic[/yellow] →")
        feedback = critic.evaluate(route)
        _print_critique(feedback)

        iteration_history.append(route)
        critique_history.append(feedback)

        # Fix 1: passed is the ONLY exit criterion
        if feedback.passed:
            console.print(f"[green bold]✓ Passed iter {iteration} (score {feedback.overall_score}/10)[/green bold]")
            break

        if not use_reflection or iteration >= effective_max:
            if not use_reflection:
                console.print("[dim]No-reflection mode: single pass complete.[/dim]")
            else:
                console.print(f"[yellow]Max iterations reached (score {feedback.overall_score}/10)[/yellow]")
            break

        # Reflector (Fix 4)
        console.print(f"[blue]Reflector[/blue] → score {feedback.overall_score}/10, {len(feedback.issues)} issue(s)")
        route, diff = reflector.reflect(route, feedback, iteration + 1, planner)
        reflection_diffs.append(diff)
        _print_diff(diff)

    # Fix 2: final_green_score = last critique's overall_score (single source)
    final_score = critique_history[-1].overall_score if critique_history else 0

    result = PipelineResult(
        config=config,
        smiles=smiles,
        total_iterations=len(iteration_history),
        final_route=route,
        iteration_history=iteration_history,
        critique_history=critique_history,
        reflection_diffs=reflection_diffs,
        route_validity=validity_report,
        passed=feedback.passed if feedback else False,
        final_green_score=final_score,         # Fix 2
    )

    if len(iteration_history) > 1:
        console.rule("[bold green]Before / After")
        _print_comparison(ComparatorModule().compare(result))

    return result


# ── Printers ──────────────────────────────────────────────────────────────────

def _print_route(r):
    t = Table(title=f"{r.molecule_name} — iter {r.iteration}", show_header=True, header_style="bold")
    t.add_column("#", width=3); t.add_column("Reaction", min_width=22)
    t.add_column("Solvent", min_width=16); t.add_column("Conditions")
    for s in r.steps:
        sc = s.green_score
        sc_str = (f"[green]{sc}[/green]" if sc >= 7 else f"[yellow]{sc}[/yellow]" if sc >= 5
                  else f"[red]{sc}[/red]") if sc >= 0 else "[dim]?[/dim]"
        t.add_row(str(s.step), s.reaction_name, f"{s.solvent} {sc_str}", s.conditions)
    console.print(t)

def _print_critique(fb):
    col  = "green" if fb.passed else ("yellow" if fb.overall_score >= 5 else "red")
    body = (f"[bold]Score:[/bold] [{col}]{fb.overall_score}/10[/{col}]  "
            f"[bold]Passed:[/bold] {'[green]Yes[/green]' if fb.passed else '[red]No[/red]'}\n"
            f"{fb.feedback_summary}")
    if fb.issues:
        body += "\n" + "\n".join(
            f"  Step {i.step}: {i.problem} → [cyan]{i.suggestion}[/cyan]"
            for i in fb.issues)
    console.print(Panel(body, title="Critic", border_style=col))

def _print_diff(diff):
    lines = [f"  [green]✓[/green] Step {c.step}: [red]{c.original_solvent}[/red] → [green]{c.replacement_solvent}[/green]"
             for c in diff.permitted_changes]
    lines += [f"  [yellow]⚠[/yellow] Blocked: {r}" for r in diff.rejected_changes]
    if lines:
        console.print(Panel("\n".join(lines), title="ReflectionDiff", border_style="dim"))

def _print_comparison(rep):
    b, a, d = rep["before"], rep["after"], rep["delta"]
    body = (f"[bold]Green score:[/bold] [red]{b['overall_green_score']}/10[/red] → "
            f"[green]{a['overall_green_score']}/10[/green]  (+{d['green_score']})\n"
            f"[bold]PMI:[/bold]  [red]{b['pmi']}[/red] → [green]{a['pmi']}[/green]  (-{d['pmi_reduction_pct']}%)\n"
            f"[bold]Steps changed:[/bold] {d['steps_changed']}\n"
            + "\n".join(f"  Step {s['step']}: [red]{s['before']}[/red]({s['score_before']}) "
                        f"→ [green]{s['after']}[/green]({s['score_after']})  Δ=+{s['delta']}"
                        for s in d["solvents_improved"]))
    console.print(Panel(body, title="Before / After", border_style="green"))


# ── CLI ────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--smiles",          required=True)
    p.add_argument("--max-iter",        type=int,  default=int(os.getenv("MAX_ITERATIONS", 3)))
    p.add_argument("--threshold",       type=int,  default=int(os.getenv("GREEN_SCORE_THRESHOLD", 7)))
    p.add_argument("--no-reflection",   action="store_true")
    p.add_argument("--rule-baseline",   action="store_true")   # Fix 5
    p.add_argument("--output",          default=None)
    args = p.parse_args()

    result = run_pipeline(
        smiles=args.smiles,
        max_iter=args.max_iter,
        threshold=args.threshold,
        use_reflection=not args.no_reflection,
        rule_baseline=args.rule_baseline,
    )
    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w") as f:
            json.dump(result.model_dump(), f, indent=2, default=str)
        console.print(f"[dim]Saved → {args.output}[/dim]")
