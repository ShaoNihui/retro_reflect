"""
Tests for all 6 fixes.
pytest tests/test_modules.py -v
"""
import pytest, copy
from unittest.mock import MagicMock

# Bootstrap pydantic + external deps
import types, sys

pydantic_mock = types.ModuleType("pydantic")

class BaseModel:
    def __init__(self, **kw):
        for k, v in kw.items(): setattr(self, k, v)
    def model_dump(self):
        return {k:v for k,v in self.__dict__.items() if not k.startswith('_')}

def Field(default=None, **kw): return default
pydantic_mock.BaseModel = BaseModel
pydantic_mock.Field     = Field
sys.modules["pydantic"] = pydantic_mock

for m in ["rdkit","rdkit.Chem","rdkit.Chem.AllChem","rdkit.Chem.Descriptors",
          "rdkit.Chem.rdMolDescriptors","langchain_core","langchain_core.prompts",
          "langchain_core.output_parsers","langchain_openai","langchain_anthropic"]:
    sys.modules[m] = MagicMock()

import importlib.util, os

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m    = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load(f"{B}/data/solvent_db.py",           "data.solvent_db")
models    = load(f"{B}/retro_reflect/modules/models.py",          "modules.models")
vc_mod    = load(f"{B}/retro_reflect/modules/validity_check.py",  "modules.validity_check")
critic_m  = load(f"{B}/retro_reflect/modules/critic.py",          "modules.critic")
planner_m = load(f"{B}/retro_reflect/modules/planner.py",         "modules.planner")
reflect_m = load(f"{B}/retro_reflect/modules/reflector.py",       "modules.reflector")
comp_m    = load(f"{B}/retro_reflect/modules/comparator.py",       "modules.comparator")
rb_mod    = load(f"{B}/retro_reflect/modules/rule_baseline.py",   "modules.rule_baseline")

from data.solvent_db import SOLVENT_DB
M = models   # shorthand

def step(n, solvent, reaction=None, score=-1):
    return M.ReactionStep(step=n, reaction_name=reaction or f"R{n}",
                          reagents=["r1"], solvent=solvent, conditions="RT",
                          green_score=score, score_reason="")

def route(solvents, iteration=1, gs=-1, pmi=0.0):
    steps = [step(i+1, s) for i,s in enumerate(solvents)]
    return M.SynthesisRoute(molecule_name="Test", smiles="CCO",
                            steps=steps, iteration=iteration,
                            overall_green_score=gs, pmi=pmi,
                            validity_blocked=False)

def critique(score, issues=None):
    passed = score >= 7 and not issues
    return M.CriticFeedback(passed=passed, overall_score=score,
                            issues=issues or [], feedback_summary="ok")


# ── Fix 1: passed is sole exit criterion ─────────────────────────────────────

class TestFix1PassedOnlyExit:

    def test_critic_overall_score_set_from_db_not_llm(self):
        """CriticModule must derive overall_score from SOLVENT_DB, not LLM output."""
        cm = critic_m.CriticModule(MagicMock())
        score, _, _ = cm._db_score("benzene")
        assert score == 0
        score, _, _ = cm._db_score("water")
        assert score == 10

    def test_passed_false_when_any_step_below_5(self):
        cm = critic_m.CriticModule(MagicMock())
        cm._chain = MagicMock()
        cm._chain.invoke = MagicMock(return_value={"issues": [], "feedback_summary": ""})
        r = route(["benzene", "ethanol"])
        fb = cm.evaluate(r)
        assert fb.passed is False
        assert fb.overall_score < 7   # (0+8)//2 = 4

    def test_passed_true_all_steps_green(self):
        cm = critic_m.CriticModule(MagicMock())
        cm._chain = MagicMock()
        cm._chain.invoke = MagicMock(return_value={"issues": [], "feedback_summary": ""})
        r = route(["ethanol", "water"])
        fb = cm.evaluate(r)
        assert fb.passed is True
        assert fb.overall_score >= 7


# ── Fix 2: final_green_score from critique_history[-1] ───────────────────────

class TestFix2FinalGreenScore:

    def test_pipeline_result_final_score_equals_last_critique(self):
        r  = route(["ethanol"])
        fb = critique(8)
        pr = M.PipelineResult(
            smiles="CCO", total_iterations=1,
            final_route=r, iteration_history=[r],
            critique_history=[fb],
            passed=True,
            final_green_score=fb.overall_score,   # must use critique, not route
        )
        assert pr.final_green_score == 8
        assert pr.final_green_score == pr.critique_history[-1].overall_score

    def test_final_score_not_from_route_field(self):
        r  = route(["ethanol"], gs=999)   # deliberately wrong route field
        fb = critique(8)
        pr = M.PipelineResult(
            smiles="CCO", total_iterations=1,
            final_route=r, iteration_history=[r],
            critique_history=[fb],
            passed=True,
            final_green_score=fb.overall_score,
        )
        assert pr.final_green_score == 8   # from critique, not route.overall_green_score


# ── Fix 3: ValidityCheck blocks route ────────────────────────────────────────

class TestFix3ValidityBlocks:

    def setup_method(self):
        self.vc = vc_mod.ValidityCheckModule()

    def test_unknown_solvent_is_blocking(self):
        r   = route(["green solvent"])
        rep = self.vc.validate(r)
        assert rep.has_blocking_issues
        assert rep.route_chemically_valid is False

    def test_grignard_water_is_blocking(self):
        r = route(["water"])
        r.steps[0].reagents = ["grignard reagent"]
        rep = self.vc.validate(r)
        assert rep.has_blocking_issues

    def test_too_many_steps_blocking(self):
        r = route(["ethanol"] * 9)
        rep = self.vc.validate(r)
        assert rep.has_blocking_issues

    def test_valid_route_not_blocked(self):
        r   = route(["ethanol", "water"])
        rep = self.vc.validate(r)
        assert not rep.has_blocking_issues
        assert rep.route_chemically_valid is True

    def test_blocking_sets_validity_blocked(self):
        """Pipeline must set route.validity_blocked=True on blocking report."""
        r   = route(["mystery solvent xyz"])
        rep = self.vc.validate(r)
        if rep.has_blocking_issues:
            r.validity_blocked = True
        assert r.validity_blocked is True


# ── Fix 4: Reflector split from Planner ──────────────────────────────────────

class TestFix4ReflectorSplit:

    def test_planner_has_no_reflect_method(self):
        pm = planner_m.PlannerModule(MagicMock())
        assert not hasattr(pm, "reflect_and_revise"), \
            "reflect_and_revise must be removed from PlannerModule (moved to Reflector)"

    def test_planner_has_apply_replacements(self):
        pm = planner_m.PlannerModule(MagicMock())
        assert callable(getattr(pm, "apply_replacements", None))

    def test_reflector_calls_planner_apply_replacements(self):
        rm = reflect_m.ReflectorModule()
        r  = route(["benzene"], iteration=1)
        fb = M.CriticFeedback(passed=False, overall_score=2,
                              issues=[M.CriticIssue(step=1, problem="carcinogen",
                                                    suggestion="ethanol")],
                              feedback_summary="fix step 1")
        mock_planner = MagicMock()
        revised_r = route(["ethanol"], iteration=2)
        mock_planner.apply_replacements = MagicMock(return_value=(revised_r, []))
        result_r, diff = rm.reflect(r, fb, iteration=2, planner=mock_planner)
        mock_planner.apply_replacements.assert_called_once()
        assert len(diff.permitted_changes) == 1
        assert diff.permitted_changes[0].replacement_solvent == "ethanol"

    def test_reflector_empty_diff_when_no_issues(self):
        rm = reflect_m.ReflectorModule()
        r  = route(["ethanol"], iteration=1)
        fb = critique(8)   # passed, no issues
        mock_planner = MagicMock()
        revised_r, diff = rm.reflect(r, fb, iteration=2, planner=mock_planner)
        assert len(diff.permitted_changes)  == 0
        assert len(diff.rejected_changes)   == 0
        mock_planner.apply_replacements.assert_not_called()

    def test_planner_apply_replacements_only_changes_solvent(self):
        pm  = planner_m.PlannerModule(MagicMock())
        r   = route(["benzene"], iteration=1)
        r.steps[0].reaction_name = "Fischer Esterification"
        r.steps[0].reagents      = ["acetic anhydride", "H2SO4"]
        rep = [M.SolventReplacement(step=1, original_solvent="benzene",
                                    replacement_solvent="ethyl acetate",
                                    reason="carcinogen")]
        revised, rejected = pm.apply_replacements(r, rep, iteration=2)
        assert revised.steps[0].solvent       == "ethyl acetate"
        assert revised.steps[0].reaction_name == "Fischer Esterification"
        assert revised.steps[0].reagents      == ["acetic anhydride", "H2SO4"]
        assert len(rejected) == 0

    def test_planner_apply_replacements_skips_same_solvent(self):
        pm  = planner_m.PlannerModule(MagicMock())
        r   = route(["ethanol"], iteration=1)
        rep = [M.SolventReplacement(step=1, original_solvent="ethanol",
                                    replacement_solvent="ethanol",
                                    reason="already green")]
        revised, rejected = pm.apply_replacements(r, rep, iteration=2)
        assert len(rejected) == 1
        assert "same" in rejected[0]


# ── Fix 5: Rule-based baseline ───────────────────────────────────────────────

class TestFix5RuleBaseline:

    def test_rule_baseline_replaces_toxic_solvents(self):
        r  = route(["benzene", "ethanol"], iteration=1)
        pr = rb_mod.run_rule_baseline(r, "CCO")
        final = pr.final_route
        solvents = [s.solvent.lower() for s in final.steps]
        assert "benzene" not in solvents, "benzene must be replaced"

    def test_rule_baseline_config_flag(self):
        r  = route(["ethanol"], iteration=1)
        pr = rb_mod.run_rule_baseline(r, "CCO")
        assert pr.config.use_rule_baseline is True
        assert pr.config.use_reflection    is False

    def test_rule_baseline_already_green(self):
        r  = route(["water", "ethanol"], iteration=1)
        pr = rb_mod.run_rule_baseline(r, "CCO")
        assert pr.total_iterations == 1
        assert pr.passed is True

    def test_rule_baseline_has_no_llm_call(self):
        """Rule baseline must work with no LLM instance available."""
        r  = route(["dichloromethane", "water"], iteration=1)
        pr = rb_mod.run_rule_baseline(r, "CCO")
        assert isinstance(pr, M.PipelineResult)
        assert pr.final_green_score >= 0


# ── Fix 6: Unified step-level schema ─────────────────────────────────────────

class TestFix6UnifiedSchema:

    def test_green_score_sentinel_default(self):
        s = step(1, "ethanol")
        assert s.green_score == -1, "default must be -1 (not None)"

    def test_critic_always_sets_int_green_score(self):
        cm = critic_m.CriticModule(MagicMock())
        cm._chain = MagicMock()
        cm._chain.invoke = MagicMock(return_value={"issues":[], "feedback_summary":""})
        r  = route(["ethanol", "benzene"])
        cm.evaluate(r)
        for s in r.steps:
            assert isinstance(s.green_score, int)
            assert s.green_score >= 0, "after Critic, green_score must be >= 0"

    def test_comparator_uses_step_green_score_not_db_lookup(self):
        comp = comp_m.ComparatorModule()
        # Pre-set green_score to values that differ from DB
        r1 = route(["ethanol"], iteration=1, gs=3, pmi=12.0)
        r1.steps[0].green_score = 3    # deliberately different from DB's 8
        r2 = route(["water"],   iteration=2, gs=9, pmi=5.0)
        r2.steps[0].green_score = 9
        pr = M.PipelineResult(
            smiles="CCO", total_iterations=2,
            final_route=r2, iteration_history=[r1, r2],
            critique_history=[critique(3), critique(9)],
            passed=True, final_green_score=9,
        )
        rep = comp.compare(pr)
        # Should use step.green_score (3, 9) not DB lookup (8, 10)
        assert rep["before"]["steps"][0]["green_score"] == 3
        assert rep["after"]["steps"][0]["green_score"]  == 9

    def test_scoring_formula_consistent_across_modules(self):
        """int(mean of step scores) must be the same in Critic, Comparator, RuleBaseline."""
        cm = critic_m.CriticModule(MagicMock())
        cm._chain = MagicMock()
        cm._chain.invoke = MagicMock(return_value={"issues":[], "feedback_summary":""})
        r  = route(["benzene", "ethanol"])   # scores: 0, 8 → mean = 4
        fb = cm.evaluate(r)
        assert fb.overall_score == 4

    def test_rule_baseline_same_formula(self):
        r  = route(["benzene", "ethanol"])
        score, _ = rb_mod._score_route(r)
        assert score == 4   # (0 + 8) // 2 = 4, same as Critic


# ── Solvent DB ────────────────────────────────────────────────────────────────

class TestSolventDB:
    def test_all_fields(self):
        for n, e in SOLVENT_DB.items():
            assert "score"  in e, f"{n}: missing score"
            assert "hazard" in e, f"{n}: missing hazard"
            assert "alt"    in e, f"{n}: missing alt"
    def test_score_range(self):
        assert all(0 <= e["score"] <= 10 for e in SOLVENT_DB.values())
    def test_known_values(self):
        assert SOLVENT_DB["benzene"]["score"]       == 0
        assert SOLVENT_DB["water"]["score"]         == 10
        assert SOLVENT_DB["ethanol"]["score"]       == 8
        assert SOLVENT_DB["ethyl acetate"]["score"] == 7
        assert SOLVENT_DB["dichloromethane"]["score"]== 2
